package AdvanceSelenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions opt=new ChromeOptions();
		
		opt.addArguments("--disable-dev-shm-usage");
		opt.addArguments("--ignore-ssl-errors=yes");
		opt.addArguments("--ignore-certificate-errors");
		
		
		WebDriver driver=new ChromeDriver(opt);
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		///Simple alert
		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		
		
		//Confirmation Alert
		driver.navigate().refresh();
		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		Thread.sleep(3000);
		//driver.switchTo().alert().dismiss();
		
		driver.switchTo().alert().accept();
		
		
		//Prompt Alert 
		driver.navigate().refresh();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[text()='Alert with Textbox ']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Alert alert=driver.switchTo().alert();
		Thread.sleep(3000);
		alert.sendKeys("Saurabh");
		alert.accept();
		
	String TextValue=	driver.findElement(By.xpath("//p[@id='demo1']")).getText();
		System.out.println("The text value present in webpage is  "+TextValue);
		
		
		
		
		
		
		
		

	}

}
