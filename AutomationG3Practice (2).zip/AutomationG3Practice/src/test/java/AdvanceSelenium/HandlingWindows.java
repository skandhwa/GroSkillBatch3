package AdvanceSelenium;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		
		
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String WindowId=	driver.getWindowHandle();
	System.out.println("The Window Id is  "+WindowId);
	String Title=driver.getTitle();
	System.out.println("The title of WebPage is   "+Title);
	
	driver.findElement(By.xpath("(//button[@class='btn btn-info'])[1]")).click();
	Set<String> WindowIds=driver.getWindowHandles();
	System.out.println("The window id for both windows are  "+WindowIds);
	
	Iterator<String> itr=WindowIds.iterator();
	
	while(itr.hasNext())///
	{
		String childWindow=itr.next();//B
		if(!WindowId.equals(childWindow))///A!=B
		{
			driver.switchTo().window(childWindow);
			String titleChild=driver.getTitle();
			System.out.println("The title of child window "+titleChild);
			Thread.sleep(5000);
			driver.findElement(By.xpath("//a[@id='navbarDropdown']")).click();
			
		}
		
		
		
	}
	
	
	
	
	
	
	
	
		
		

	}

}
