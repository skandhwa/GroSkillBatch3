package HandlingActionClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DynamicDragAndDrop {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Dynamic.html");
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
		
		WebElement src1=	driver.findElement(By.xpath("//*[@id='angular']"));
		WebElement src2=driver.findElement(By.xpath("//*[@id='mongo']"));
		WebElement src3=driver.findElement(By.xpath("//*[@id='node']"));
		//WebElement target1=driver.findElement(By.xpath("//div[@class='dragged']")); 
		
		act.dragAndDropBy(src1, 120, 50).build().perform();
		
		
		
	}

}
