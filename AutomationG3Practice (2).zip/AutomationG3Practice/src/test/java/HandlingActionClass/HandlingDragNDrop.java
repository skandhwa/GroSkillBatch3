package HandlingActionClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDragNDrop {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Static.html");
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
	WebElement src1=	driver.findElement(By.xpath("//*[@id='angular']"));
		WebElement src2=driver.findElement(By.xpath("//*[@id='mongo']"));
		WebElement src3=driver.findElement(By.xpath("//*[@id='node']"));
		
		
	WebElement target=driver.findElement(By.xpath("//*[@id='droparea']"));
	
	act.dragAndDrop(src1, target).build().perform();
	act.dragAndDrop(src2, target).build().perform();
	act.dragAndDrop(src3, target).build().perform();
	
	
	
	
		
		

	}

}
