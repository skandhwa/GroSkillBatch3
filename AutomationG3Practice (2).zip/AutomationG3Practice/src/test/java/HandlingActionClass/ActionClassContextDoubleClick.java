package HandlingActionClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionClassContextDoubleClick {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
	WebElement ele=	driver.findElement(By.xpath("//*[text()='right click me']"));
		act.contextClick(ele).build().perform();
		Thread.sleep(3000);
		driver.navigate().refresh();
		
	WebElement ele2=	driver.findElement(By.xpath("//*[text()='Double-Click Me To See Alert']"));
		act.doubleClick(ele2).build().perform();
		
		driver.switchTo().alert().accept();
		
		
		
		
		
		

	}

}
