package HandlingActionClass;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class KeyboardActions {

	public static void main(String[] args) throws AWTException, InterruptedException {
		
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://demoqa.com/text-box");
		 driver.manage().window().maximize();
		 driver.findElement(By.xpath("//input[@id='userName']")).sendKeys("Saurabh");
		 driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("abc@gmail.com");
		 driver.findElement(By.xpath("//textarea[@id='currentAddress']")).sendKeys("flat no 12 PR Appartment delhi");
		 
		 Actions act=new Actions(driver);
		 /////select the entire content
		 
		 JavascriptExecutor js=(JavascriptExecutor)driver;
		 js.executeScript("window.scrollBy(0,800)", " ");
		 
		 
		 act.keyDown(Keys.CONTROL);
		 act.sendKeys("a");
		 act.keyUp(Keys.CONTROL);
		 act.build().perform();
		 
		 ////copy the content 
		 
		 act.keyDown(Keys.CONTROL);
		 act.sendKeys("c");
		 act.keyUp(Keys.CONTROL);
		 act.build().perform();
		 
		 ////press the tab button
		 
		 act.sendKeys(Keys.TAB);
		 act.build().perform();
		 Thread.sleep(3000);
		 
		 ////Paste the content
		 
		 act.keyDown(Keys.CONTROL);
		 act.sendKeys("v");
		 act.keyUp(Keys.CONTROL);
		 act.build().perform();
		 
		 
		 
		 
		 
		 
		 
		 

	}

}
	

