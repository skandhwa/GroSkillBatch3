package HandlingActionClass;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HorizontalScrollingEx {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
	WebElement horizontalScroll=	driver.findElement(By.xpath("//iframe[@id='google_esf']"));
		
		Actions act=new Actions(driver);
		Actions x=act.moveToElement(horizontalScroll);
		
		for(int i=0;i<5;i++)
		{
			x.sendKeys(Keys.RIGHT).build().perform();
		}
		
		
		
		
		
		

	}

}
