package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserCommands {

	public static void main(String[] args) {
		
		WebDriver driver=new EdgeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
	String Title=	driver.getTitle();
	System.out.println("The title of Web page is  "+Title);
	
	driver.findElement(By.xpath("//a[text()='Gmail']")).click();///to be ignored now
String CurrentUrl=	driver.getCurrentUrl();
System.out.println("The current Url is "+CurrentUrl);

	
	
	
		
		

	}

}
