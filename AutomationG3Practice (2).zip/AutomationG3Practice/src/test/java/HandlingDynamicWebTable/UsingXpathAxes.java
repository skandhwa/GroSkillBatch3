package HandlingDynamicWebTable;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UsingXpathAxes {

	public static void main(String[] args) {
		

		WebDriver driver=new ChromeDriver();
		driver.get("https://cosmocode.io/automation-practice-webtable/");
		driver.manage().window().maximize();
		//driver.findElement(By.xpath("//*[text()='Australia']//parent::td//preceding-sibling::td//input[@type='checkbox']")).click();
		
//		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the country name you want to select");
		String countryName=sc.nextLine();
		
		
		
		String beforexpath = "//*[@id='countries']/tbody/tr[";
		String afterxpath ="]/td[2]";

		String beforexpathcheckbox="//*[@id='countries']/tbody/tr[";
		String afterxpathcheckbox ="]/td[1]/input";


		List <WebElement> li=driver.findElements(By.tagName("tr"));
		int x=li.size();
		System.out.println("number of rows:"+x);
		for (int i=2;i<x;i++)
		{
		String countryname = driver.findElement(By.xpath(beforexpath+i+afterxpath)).getText();
		System.out.println(countryname);
		if(countryname.equalsIgnoreCase(countryName))
		{
		driver.findElement(By.xpath(beforexpathcheckbox+i+afterxpathcheckbox)).click();
		}
		}
		
		

	}

}
