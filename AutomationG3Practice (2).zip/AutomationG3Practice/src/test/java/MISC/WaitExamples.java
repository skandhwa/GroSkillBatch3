package MISC;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitExamples {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		//driver.get("https://cosmocode.io/automation-practice-webtable/");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		WebDriverWait x=new WebDriverWait(driver,Duration.ofSeconds(5));
		WebElement ele2=x.until(ExpectedConditions.
				elementToBeClickable(By.xpath("//select[@id='continents']")));
		
		
		
		
		
		WebElement ele=new 
				WebDriverWait(driver,Duration.ofSeconds(5)).
				until(ExpectedConditions.
	elementToBeClickable(By.xpath("//select[@id='continents']")));
				
				
		
	WebElement ele1=driver.findElement(By.xpath("//input[@id='firstname']"));
	WebElement ele3=driver.findElement(By.xpath("//input[@id='lastname']"));
	WebElement ele4=driver.findElement(By.xpath("//input[@id='mobile']"));	
		
		
	FluentWait wait=new FluentWait(driver);
	wait.withTimeout(Duration.ofSeconds(10));
	wait.pollingEvery(Duration.ofSeconds(2));
	wait.until(ExpectedConditions.elementToBeClickable(ele1));
	//wait.until(ExpectedConditions.visibilityOf(ele3));
	wait.until(ExpectedConditions.elementToBeSelected(ele4));
	wait.ignoring(NoSuchElementException.class);
	
	
	
	try
	{
		driver.switchTo().window("windowid");
	}
	catch(NoSuchWindowException e)
	{
		System.out.println("caught with  "+e);
	}
	
	
		
		

	}

}
