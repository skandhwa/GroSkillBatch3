package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgAssertionsEx {
	
	@Test
	public void test1()
	{
		int x=10+2;
		int y=45/3;
		
		String str="hello";
		
		
		
		//Assert.assertEquals(x,y);
		
		//Assert.assertNotEquals(x,y);
		
		//Assert.assertTrue(x>y);
		
		
		Assert.assertNull(str);
		
		
		System.out.println("This scenario passed");
		
	}
	
	

}
