package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgCrossBrowserEx {
	
	public static WebDriver driver;
	
	@Parameters("browser")
	
	
	@BeforeMethod
	public void openBrowser(String browser)
	{
		if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			
		}
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			
		}
		else if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			
		}
	}
	
	
	@Test
	
	public void test()
	{
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		System.out.println(title);
		
	}
	
	
	@Test
	public void test1()
	{
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String title1=driver.getTitle();
		System.out.println(title1);
	}
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.quit();
	}
	
	
	
	
	
	
	
	
	
	

}
