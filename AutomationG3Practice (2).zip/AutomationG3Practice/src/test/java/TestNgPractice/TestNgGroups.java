package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgGroups {
	
	@Test(groups = { "sanity", "regression" })
	public void test1()
	{
		System.out.println("I am test 1 sanity ");
	}
	
	@Test(groups="regression")
	public void test2()
	{
		System.out.println("I am test 2 regression ");
	}
	
	@Test(groups="smokeB")
	public void test3()
	{
		System.out.println("I am test 3 smoke ");
	}
	
	@Test(groups="regression")
	public void test4()
	{
		System.out.println("I am test 4 regression ");
	}

	@Test(groups="smokeA")
	public void test5()
	{
		System.out.println("I am test 5 smoke ");
	}
	
	@Test(groups="sanity2")
	public void test6()
	{
		System.out.println("I am test 6 sanity ");
	}
	
	
	
}
