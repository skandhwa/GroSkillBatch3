package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetTagNameGetSize {

	public static void main(String[] args) throws InterruptedException {
	
		
		WebDriver driver=new ChromeDriver();
//		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
//		driver.manage().window().maximize();
//	WebElement ele=	driver.findElement(By.name("firstname"));
//	String TagName=ele.getTagName();
//	System.out.println("The tag name is   "+TagName);
		
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		Dimension d=ele.getSize();
		System.out.println("Height is  "+d.height +"Width is   "+d.width);
		
		Point p=ele.getLocation();
		System.out.println(" X coordinate is  "+p.x+"   Y coordinate is  "+p.y);
	
		
		ele.sendKeys("Saurabh");
		
		Thread.sleep(3000);
		
		ele.clear();
	
		
		
			
			
			

	}

}
