package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropDowns {

	public static void main(String[] args) {


		 WebDriver driver=new ChromeDriver();
		 driver.get("https://demo.automationtesting.in/Register.html");
		 driver.manage().window().maximize();
	WebElement ele=	 driver.findElement(By.xpath("//select[@id='Skills']"));
	Select oselect=new Select(ele);
	//oselect.selectByIndex(2);
	//oselect.selectByVisibleText("AutoCAD");
	//oselect.selectByValue("Configuration");
	//oselect.selectByContainsVisibleText("Auto");
	
	
	
	

	}

}
