package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands3 {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@id='checkbox1']"));
	boolean flag=	ele.isSelected();
	
	System.out.println(flag);
	if(flag==false)
	{
		ele.click();
	}
	
	
		

	}

}
