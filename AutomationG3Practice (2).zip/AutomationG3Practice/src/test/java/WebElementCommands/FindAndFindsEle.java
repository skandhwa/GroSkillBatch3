package WebElementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindAndFindsEle {

	public static void main(String[] args) {
		
            WebDriver driver=new ChromeDriver();
//            driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
//            driver.manage().window().maximize();
//            
       //WebElement ele=driver.findElement(By.xpath("//input[@name='FIRSTNAME']"));
//            
		
            
            driver.get("https://demo.automationtesting.in/Register.html");
            
    List<WebElement> li=        driver.findElements(By.tagName("a"));
    
   int x= li.size();
   System.out.println("The total number of links are  "+x);
   
   for(int i=0;i<x;i++)
   {
	   System.out.println(li);
   }
    
		
		
	}

}
