package WebElementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectGetOptions {

	public static void main(String[] args) throws InterruptedException {
		
	WebDriver driver=new ChromeDriver();
	driver.get("https://demo.automationtesting.in/Register.html");
    driver.manage().window().maximize();
	WebElement ele=	 driver.findElement(By.xpath("//select[@id='Skills']"));
	Select oselect=new Select(ele);
	
	List<WebElement> li=oselect.getOptions();
	System.out.println("All dropdown values are  ");
	
	for(WebElement x:li)
	{
		System.out.println(x.getText());
	}
	Thread.sleep(3000);
	

	boolean flag=false;
 for (WebElement x : li) {
     if (x.getText().equalsIgnoreCase("Maya")) {
         flag = true;
         break;
     }
     
     
     
 }
 System.out.println("Does the list contains Maya  "+flag);
 
		

	}

}
