//package MISC;
//
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.util.List;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//public class HandlingBrokenLinks {
//
//	
//		public static void main(String[] args) {
//	        WebDriver driver = new ChromeDriver();
//	        driver.get("https://example.com"); // Replace with your target URL
//
//	        List<WebElement> links = driver.findElements(By.tagName("a"));
//	        System.out.println("Total links: " + links.size());
//
//	        for (WebElement link : links) {
//	            String url = link.getAttribute(link);
//	            if (url == null || url.isEmpty()) {
//	                System.out.println("Empty or null URL");
//	                continue;
//	            }
//
//	            try {
//	                HttpURLConnection connection = (HttpURLConnection) (new URL(url).openConnection());
//	                connection.setRequestMethod("HEAD");
//	                connection.connect();
//	                int responseCode = connection.getResponseCode();
//
//	                if (responseCode >= 400) {
//	                    System.out.println("Broken link: " + url + " | Code: " + responseCode);
//	                } else {
//	                    System.out.println("Valid link: " + url + " | Code: " + responseCode);
//	                }
//
//	            } catch (Exception e) {
//	                System.out.println("Exception checking link: " + url + " | Error: " + e.getMessage());
//	            }
//	        }
//
//	        driver.quit();
//	    }
//	}
//
//	
//
//
