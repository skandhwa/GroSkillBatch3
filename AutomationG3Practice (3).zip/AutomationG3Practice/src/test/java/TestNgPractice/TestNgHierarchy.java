
package TestNgPractice;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class TestNgHierarchy {
	
	@BeforeClass
	public void A()
	{
		System.out.println("I am before class");///2
	}
	
	@AfterSuite
	public void B()
	{
		System.out.println("I am After Suite");//6
	}
	
	@BeforeMethod
	public void C()
	{
		System.out.println("I am Before Method");///3
	}
	
	@Test
	public void D()
	{
		System.out.println("I am Test"); ////4
	}
	
	

	@BeforeTest
	public void E()
	{
		System.out.println("I am before Test");////1
	}
	
	@AfterMethod
	public void F()
	{
		System.out.println("I am after method");//5
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
