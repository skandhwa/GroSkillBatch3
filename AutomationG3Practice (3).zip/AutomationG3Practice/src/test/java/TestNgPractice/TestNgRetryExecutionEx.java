package TestNgPractice;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class TestNgRetryExecutionEx implements IRetryAnalyzer {

	int retryLimit=3;
	int count=0;
	
	
	public boolean retry(ITestResult result) {
		
		if(count<retryLimit)///1<3
		{
			count++;
			return true;
		}
		
		
		
		
		
		return false;
	}
	
	
	
	
	
	
	
	
	

}
