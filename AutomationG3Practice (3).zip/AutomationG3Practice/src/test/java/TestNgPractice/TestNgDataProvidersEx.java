package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDataProvidersEx {
	
	WebDriver driver;
	@DataProvider(name="dp1")
	public Object[][] dpmethod()
	{
	return new Object[][]
	{
	{"Java"},{"Selenium testing"},{"php"},{"xml"}
	};
	}
	
	@Test(dataProvider="dp1")
	public void searchGoogle(String keyword) throws InterruptedException
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
		ele.sendKeys(keyword);
		Thread.sleep(3000);
		ele.sendKeys(Keys.ENTER);
		
	}
	
	@AfterMethod
	public void closeBrowser() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.quit();
	}
	
	
	
	
	
	

}

