package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgGroups2 {
	
	@Test(groups="sanity1")
	public void test7()
	{
		System.out.println("I am test 7 sanity ");
	}
	
	@Test(groups="regression")
	public void test8()
	{
		System.out.println("I am test 8 regression ");
	}
	
	@Test(groups="smokeB")
	public void test9()
	{
		System.out.println("I am test 9 smoke ");
	}
	
	@Test(groups="regression")
	public void test10()
	{
		System.out.println("I am test 10 regression ");
	}

	@Test(groups="smokeA")
	public void test11()
	{
		System.out.println("I am test 11 smoke ");
	}
	
	@Test(groups="sanity2")
	public void test12()
	{
		System.out.println("I am test 12 sanity ");
	}
	

}
