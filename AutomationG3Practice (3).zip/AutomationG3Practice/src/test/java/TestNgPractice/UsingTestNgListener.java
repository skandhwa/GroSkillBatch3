package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(value=TestNgPractice.UsingItestResult.class)

public class UsingTestNgListener {
	
	@Test
	public void test1()
	{
		DriverInitialization.initializeDriver().get("https://www.google.com");
		String title=DriverInitialization.initializeDriver().getTitle();
		Assert.assertEquals(title,"Google123");
		
		
	}
	
	
	
	

}
