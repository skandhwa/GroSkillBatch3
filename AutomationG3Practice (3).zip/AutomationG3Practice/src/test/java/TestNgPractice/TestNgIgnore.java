package TestNgPractice;

import org.testng.annotations.Ignore;
import org.testng.annotations.Test;


@Ignore
public class TestNgIgnore {
	
	@Test()
	public void test1()
	{
		System.out.println("Hello I will be ignored");
	}
	
	
	

}
