package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UsingRetryAnalyzer {
	
	@Test(retryAnalyzer=TestNgPractice.TestNgRetryExecutionEx.class)
	
	public void display() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	String title=	driver.getTitle();
	Assert.assertEquals(title,"Google123");
	Thread.sleep(3000);
	driver.quit();
	
	
		
	}
	
	
	
	
	
	

}
