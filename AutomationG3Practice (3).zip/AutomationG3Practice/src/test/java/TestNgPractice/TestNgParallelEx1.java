package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class TestNgParallelEx1 {
	
	
	
	public WebDriver driver;
	
	@Test
	public void testGoogle()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
	}
	
	@Test
	public void testfacebook()
	{
		driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
	}
	
	@Test
	public void testInstagram()
	{
		driver=new ChromeDriver();
		driver.get("https://www.instagram.com");
	}
	
	@Test
	public void testFlipkart()
	{
		driver=new ChromeDriver();
		driver.get("https://www.flipkart.com");
	}
	
	
	@Test
	public void testAmazon()
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
	}
	
	
	@Test
	public void testmyntra()
	{
		driver=new ChromeDriver();
		driver.get("https://www.myntra.com");
	}
	}
	
	
//	@AfterTest
//	public void closeBrowser()
//	{
//		driver.quit();
//	}
	
	
	
	


