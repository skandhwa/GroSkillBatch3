package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

public class MultiGroupTest {
	
	 @BeforeGroups({"api"})
	    public void beforeApiGroup() {
	        System.out.println(">> beforeApiGroup");
	    }

	    @AfterGroups({"api"})
	    public void afterApiGroup() {
	        System.out.println(">> afterApiGroup");
	    }

	    @Test(groups = {"smoke", "ui"})
	    public void loginUITest() {
	        System.out.println("loginUITest");
	        Assert.assertTrue(true);
	    }

	    @Test(groups = {"regression", "api"})
	    public void createUserApiTest() {
	        System.out.println("createUserApiTest");
	        Assert.assertTrue(true);
	    }

	    @Test(groups = {"sanity", "regression", "db"})
	    public void verifyUserInDbTest() {
	        System.out.println("verifyUserInDbTest");
	        Assert.assertTrue(true);
	    }

}
