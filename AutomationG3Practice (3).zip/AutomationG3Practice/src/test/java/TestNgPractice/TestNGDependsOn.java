package TestNgPractice;

import org.testng.annotations.Test;

public class TestNGDependsOn {
	
	
	@Test(priority=1)
	public void login()
	{
		int x=9/0;
		System.out.println(x);
		System.out.println("Login successfull");
	}
	
	
	@Test(dependsOnMethods= {"login"},priority=2)
	public void searchProduct()
	{
		System.out.println("SP successfull");
	}
	
	
	@Test(dependsOnMethods= {"login","searchProduct"},alwaysRun=true,priority=3)
	public void addToCart()
	{
		System.out.println("AC successfull");
	}
	
	@Test(dependsOnMethods= {"searchProduct","addToCart"},priority=4)
	public void paymentGateway()
	{
		System.out.println("PG successfull");
	}
	
	
	

}
