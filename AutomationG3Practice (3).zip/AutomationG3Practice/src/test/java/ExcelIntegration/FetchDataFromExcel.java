package ExcelIntegration;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FetchDataFromExcel {

	public static void main(String[] args) throws IOException  {
		
		
		///‪E:\TestData29thJuly.xlsx
		
		FileInputStream fs=new FileInputStream("‪src/test/java/ExcelIntegration/TestData28thJuly.xlsx");
		XSSFWorkbook wb=new XSSFWorkbook(fs);
		XSSFSheet sheet=wb.getSheetAt(0);
		XSSFCell value= sheet.getRow(1).getCell(0);
		String Fname=value.toString();
		
		XSSFCell value2= sheet.getRow(1).getCell(1);
		String Lname=value2.toString();
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
	WebElement ele1=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
	WebElement ele2=	driver.findElement(By.xpath("//input[@placeholder='Last Name']"));
		
	ele1.sendKeys(Fname);
	ele2.sendKeys(Lname);
	
	
		
		
		
		
		
		
		

	}

}
