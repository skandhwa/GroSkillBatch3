package OopsConcepts;

class A4
{
	String color="blue";
	void test()
	{
		System.out.println(color);
	}
}

class A5 extends A4
{
	String color="red";
	void message()
	{
		System.out.println(super.color);
	}
	
	
}



public class SuperKeywordEx {

	public static void main(String[] args) {
		
		A5 obj=new A5();
		obj.message();
		
		
		
		

	}

}
