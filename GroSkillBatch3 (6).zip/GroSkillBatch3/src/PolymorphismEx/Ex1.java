package PolymorphismEx;

class P1
{
	int sum(int x,int y)
	{
		return x+y;
	}
	
	float sum(int a,int b)
	{
		return a+b;
	}
}




public class Ex1 {

	public static void main(String[] args) {
		
		P1 obj=new P1();
	System.out.println(obj.sum(12, 13));	
		
	System.out.println	(obj.sum(13.5f, 34));
		

	}

}
