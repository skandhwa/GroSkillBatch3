package AbstractionEx;

interface I4
{
	void test();
	void message ();
	
}

interface I5 extends I4
{
	void display();
}

class C6 implements I5
{

	
	public void test() {
		
		System.out.println("Hello");
		
	}

	
	public void message() {
		
		System.out.println("Hi");
		
	}

	
	public void display() {
		
		System.out.println("Welcome");
		
	}
	
}





public class InterfaceEx2 {

	public static void main(String[] args) {
		
		I5 ref=new C6();
		ref.display();
		ref.test();
		ref.message();
		
		

	}

}
