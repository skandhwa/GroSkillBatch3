package AbstractionEx;

abstract class Y1
{
	void test()
	{
		System.out.println("Hello");
	}
	
	void display2()
	{
		System.out.println("Hey how r u");
	}
	
	abstract void display();
	
	abstract void test2();
	
	static  void message3()
	{
		
	}
	
	
	
	
	
	
}

class Y2 extends Y1
{
    void display()
    {
    	System.out.println("Welcome");
    }
    
    void message()
    {
    	System.out.println("Hello how r u");
    }
    
    void test2()
    {
    	System.out.println("Hey");
    }
	
	
}




public class AbstractClassEx {

	public static void main(String[] args) {
		
		Y1 ref=new Y2();
		ref.display();
		ref.test();
		//obj.message();
		
		
		

	}

}
