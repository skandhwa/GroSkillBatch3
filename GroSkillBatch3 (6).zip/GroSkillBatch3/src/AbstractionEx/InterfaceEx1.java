package AbstractionEx;

interface I1
{
	void test();
	void display();
	void message();
	
	
}


class C1 implements I1
{
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void display()
	{
		System.out.println("Hi");
	}
	public void message()
	{
		System.out.println("Hey welcome");
	}
	
	
	
}

class C2 implements I1
{
	public void message()
	{
		System.out.println("Hey welcome");
	}
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void display()
	{
		System.out.println("Hi");
	}
}




public class InterfaceEx1 {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.test();
		obj.display();
		
		
		
		

	}

}
