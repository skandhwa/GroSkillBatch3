package ProtectedModifierEx;




public class Ex1 {
	
	protected int x=10;
	
	

	public static void main(String[] args) {
		
		Ex1 obj=new Ex1();
	System.out.println(obj.x);	
		
		

	}

}
