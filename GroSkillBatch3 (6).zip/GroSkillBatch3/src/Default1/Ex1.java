package Default1;

public class Ex1 {
	
	void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		Ex1 obj=new Ex1();
		obj.display();
				
		

	}

}
