package PublicEx;

public class Ex1 {
	
	public void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
         Ex1 obj=new Ex1();
         obj.display();
		
		
	}

}
