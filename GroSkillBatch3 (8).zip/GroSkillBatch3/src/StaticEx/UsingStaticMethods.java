package StaticEx;

class Test2
{
	static void test()
	{
		System.out.println("Hello");
	}
}

public class UsingStaticMethods {

	public static void main(String[] args) {
		
		
		Test2.test();
		
		
		

	}

}
