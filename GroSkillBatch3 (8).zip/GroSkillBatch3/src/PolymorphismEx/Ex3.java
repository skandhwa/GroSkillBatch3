package PolymorphismEx;

public class Ex3 {
	
	

	
	public static void main(int a,int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	
public static void main(String[] args) {
		
		Ex3.main(12, 24);
		

	}
	
	
	

	

}
