package PolymorphismEx;



class Bank2
{
	final int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI2 extends Bank2
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
	
	
	
}

class HDFC2 extends Bank2
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class Axis2 extends Bank2
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}




public class FinalMethodEx {

	public static void main(String[] args) {
		

	}

}
