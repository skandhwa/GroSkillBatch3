package PolymorphismEx;

class Vehicle8
{
	final static int speed=35;
     
	void Car()
	{
		speed=45;
		System.out.println(speed);
	}
	 
	
	
}




public class FinalKeywordEx {

	public static void main(String[] args) {
		
		Vehicle8 obj=new Vehicle8();
		obj.Car();
		
		

	}

}
