package PolymorphismEx;

final class F1
{
	 void display()
	{
		System.out.println("Hello");
	}
}


class F2 extends F1
{
	void msg()
	{
		System.out.println("Hi");
	}
}



public class FinalClassEx {

	public static void main(String[] args) {
		
		F2 obj=new F2();
		obj.display();
		

	}

}
