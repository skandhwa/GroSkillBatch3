package AbstractionEx;

interface I10
{
	 static void display()
	{
		System.out.println("Hello");
	}
	
	static void test()
	{
		System.out.println("Hi");
	}
}









public class InterfaceEx5 {

	public static void main(String[] args) {
		
		I10.display();
		I10.test();
		
		

	}

}
