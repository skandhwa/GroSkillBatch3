package StringPractice;

public class StringBufferEx1 {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Hello");
		sb.append("Saurabh");
		
		System.out.println(sb);
		
		sb.insert(1,"Python");
		
		System.out.println(sb);

	}

}
