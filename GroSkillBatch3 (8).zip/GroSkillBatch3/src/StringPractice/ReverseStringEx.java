package StringPractice;

public class ReverseStringEx {

	public static void main(String[] args) {
		
		String str="aba";
		
		str=str.toLowerCase();
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			revstr= revstr+str.charAt(i);
		}
		
		
		System.out.println(revstr);
		
		
		if(str.equalsIgnoreCase(revstr))
		{
			System.out.println("Both strings are palindrome");
		}
		
		else
		{
			System.out.println("Both strings are not palindrome");
		}

	}

}
