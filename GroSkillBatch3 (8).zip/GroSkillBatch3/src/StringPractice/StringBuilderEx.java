package StringPractice;

public class StringBuilderEx {

	public static void main(String[] args) {
		
		StringBuilder sb=new StringBuilder("Hello");
		
		sb.append("kandhway");
		
		System.out.println(sb);
		

	}

}
