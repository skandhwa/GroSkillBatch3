package StringPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="India is an independent country";
		
	String []s1=	str.split(" ");
	
	System.out.println(s1[3].substring(1,7));
	
	
		
		

	}

}
