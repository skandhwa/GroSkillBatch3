package StringPractice;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="Saurabh";
	str=	str.substring(2,6);
		System.out.println(str);
		
		
		
		

	}

}
