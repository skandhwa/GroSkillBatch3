package StringPractice;

public class StringBufferEx3 {

	public static void main(String[] args) {
		
		
		StringBuffer sb=new StringBuffer("Java");
		
		sb.reverse();
		
		System.out.println(sb.toString());

	}

}
