package StringPractice;

import java.util.Arrays;

public class StringAnagram {

	public static void main(String[] args) {
		
		String str="Brag";
		String str2=" Gr ab";
		
		str2=str2.replaceAll(" ","");
		
		str=str.toLowerCase();
		str2=str2.toLowerCase();
		
		if(str.length()!=str2.length())
		{
			System.out.println("Both String are not anagram");
		}
		
		else
		{
			char []ch=str.toCharArray();
			char []ch2=str2.toCharArray();
			
			Arrays.sort(ch);
			Arrays.sort(ch2);
			
			if(Arrays.equals(ch,ch2)==true)
			{
				System.out.println("Both String are anagram");
			}
			else
			{
				System.out.println("Both the string are not anagram");
			}
			
			
		}
		
		

	}

}
