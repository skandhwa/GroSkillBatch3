package PublicEx2;

import PublicEx.*;

public class Ex3 {

	public static void main(String[] args) {
		
		Ex1 obj=new Ex1();
		obj.display();
		

	}

}
