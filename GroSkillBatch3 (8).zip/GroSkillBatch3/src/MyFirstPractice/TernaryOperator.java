package MyFirstPractice;

public class TernaryOperator {

	public static void main(String[] args) {
		
		
		int a=20;
		int b=30;
		int c=40;
		
		int max=  a>b ? (a>c ?a:c) : (b>c ?b:c);
		
		System.out.println("Maximum is  "+max);

	}

}
