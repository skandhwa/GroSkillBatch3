package MyFirstPractice;

public class Variables {
	
	int x=10;
	
	public void sum()
	{
		int y=x+20;
		System.out.println("Value is "+y);
	}
	
	public void diff()
	{
		int z=y-x;
	   System.out.println("Diff is "+z);	
		
	}
	
	
	
	
	
	

	public static void main(String[] args) {
		

	}

}
