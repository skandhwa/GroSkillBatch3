package ConstructorEx;

class C2
{
	int id;
	String name;
	float salary;
	boolean isMarried;
	
	C2(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
	}
	
	C2(int i,String n,float s, boolean m)
	{
		id=i;
		name=n;
		salary=s;
		isMarried=m;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+" "+salary+"  "+isMarried );
	}
	
	
	
	
}
public class MyEx2 {

	public static void main(String[] args) {
		
		C2 obj=new C2(23,"Saurabh",78000f);
		obj.display();
		
		C2 obj1=new C2(45,"Gaurabh",90000f,true);
		obj1.display();
		
		
		
		

	}

}
