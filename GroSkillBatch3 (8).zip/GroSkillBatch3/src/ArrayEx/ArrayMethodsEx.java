package ArrayEx;

import java.util.Arrays;

public class ArrayMethodsEx {

	public static void main(String[] args) {
		
		int []a= {12,43,56,78,13};
		
	Arrays.sort(a);	
	
	
	
	
	for(int x:a)
	{
		System.out.println(x);
	}
		
		
		

	}

}
