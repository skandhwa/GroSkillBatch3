package ArrayEx;

import java.util.Arrays;

public class ArrayMethodsEx2 {

	public static void main(String[] args) {
		
		int a[]= {643,345,467,289,400};
		int b[]= {43,145,197,989,4};
		
	int x=	Arrays.compare(a,b);
	
	System.out.println("Comparaision of Array will give  "+x);
		
		
		

	}

}
