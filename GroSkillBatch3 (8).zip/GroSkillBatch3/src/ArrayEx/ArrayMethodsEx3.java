package ArrayEx;

import java.util.Arrays;

public class ArrayMethodsEx3 {

	public static void main(String[] args) {
		
		int a[]= {643,345,467,289,400};
		int b[]= {343,345,467,289,400};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);
		
		

	}

}
