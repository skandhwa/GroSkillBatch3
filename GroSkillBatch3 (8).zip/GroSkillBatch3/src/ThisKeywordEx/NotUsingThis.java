package ThisKeywordEx;

class X5
{
	int id;
	String name;
	boolean m;
	
	 X5(int id,String name,boolean m)
	{
		this.id=id;
		this.name=name;
		this.m=m;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+m);
	}
	
}


public class NotUsingThis {

	public static void main(String[] args) {
		
		X5 obj=new X5(1234,"Saurabh",true);
		obj.display();
		
		

	}

}
