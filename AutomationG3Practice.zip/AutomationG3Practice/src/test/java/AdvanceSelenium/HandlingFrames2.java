package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFrames2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
		driver.manage().window().maximize();
		
JavascriptExecutor js=(JavascriptExecutor)driver;
		
	
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,1000)", " ");
//		driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
//		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='MultipleFrames.html']")));
//		Thread.sleep(3000);
//		
//		driver.findElement(By.xpath("//iframe[@src='SingleFrame.html']")).click();
//		Thread.sleep(3000);
//		
//		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Hi");
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//a[@href='#Single']")).click();
		
		
		driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='MultipleFrames.html']")));
		Thread.sleep(3000);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src='SingleFrame.html']")));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Hi");
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@href='#Single']")).click();
		

	}

}
