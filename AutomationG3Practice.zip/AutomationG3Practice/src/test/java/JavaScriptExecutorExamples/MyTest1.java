package JavaScriptExecutorExamples;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyTest1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		js.executeScript("document.getElementById('checkbox1').click();");
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,800)", " ");
		
		
		js.executeScript("document.getElementById('firstpassword').value='Saurabh';","");
		
		Thread.sleep(3000);
		js.executeScript("location.reload()");
		js.executeScript("window.scrollBy(0,-800)", " ");
		
		//js.executeScript("alert('Hello Saurabh How are you');");
		
	String title=	js.executeScript("return document.title;").toString();
		System.out.println("The title of page is   "+title);
		
		
		
		
		
		
		
		
		
		

	}

}
