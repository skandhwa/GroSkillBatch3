package MyPractice1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
	String PageSource=	driver.getPageSource();
	System.out.println("Page Source is  "+PageSource);
	Thread.sleep(8000);
	driver.close();
		
		
		

	}

}
