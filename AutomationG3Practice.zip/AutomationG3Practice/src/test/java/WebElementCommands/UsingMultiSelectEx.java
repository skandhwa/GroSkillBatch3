package WebElementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class UsingMultiSelectEx {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
	    driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='selenium_commands']"));
	Select x=	new Select(ele);
	
	if(x.isMultiple()==true)
	{
		x.selectByIndex(0);
		x.selectByIndex(1);
		x.selectByIndex(2);
		x.selectByIndex(3);
		Thread.sleep(3000);
		//x.deselectAll();
//		x.deselectByIndex(1);
//		x.deselectByIndex(2);
		
		
		
	}
	
	List<WebElement> li=x.getAllSelectedOptions();
	for(WebElement y:li)
	{
		System.out.println(y.getText());
	}
	
	
	WebElement ele2=x.getFirstSelectedOption();
	System.out.println("The first selected option is  "+ele2.getText());
	
	System.out.println();
	System.out.println();
	
	boolean flag=false;
	 for (WebElement z : li) {
	     if (z.getText().equalsIgnoreCase("Wait Commands")) 
	     {
	         flag = true;
	         break;
	     }
	     
	 }
	
	
	 System.out.println("Does the list contains Wait Commands  "+flag);
	
	
	

	}

}
