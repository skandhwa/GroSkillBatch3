package WebElementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SendKeysAndClick {

	public static void main(String[] args) {

		 WebDriver driver=new ChromeDriver();
		 driver.get("https://demo.automationtesting.in/Register.html");
		 driver.manage().window().maximize();
WebElement ele=		 driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		ele.sendKeys("Saurabh");
		
	WebElement ele1=	driver.findElement(By.xpath("//input[@value='Male']"));
		if(ele1.isEnabled())
		{
			ele1.click();
		}
		
		
		
		
		
		

	}

}
