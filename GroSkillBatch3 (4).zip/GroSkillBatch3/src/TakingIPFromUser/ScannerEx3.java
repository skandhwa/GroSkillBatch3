package TakingIPFromUser;

import java.util.Scanner;

public class ScannerEx3 {

	public static void main(String[] args) {
		
		System.out.println("Enter a single character");
		Scanner sc=new Scanner(System.in);
		char c=sc.next().charAt(0);
		
		System.out.println("Character enetered by you is  "+c);
		

	}

}
