package ConditionalStatementsAndLooping;

public class whileLoopEx {

	public static void main(String[] args) {
		
		int i=5; ///assignment 
		
		while(i<14/3)///2<4///3<4///4<4 //// condition checking 
		{
			System.out.println(i);//2//3
			i++;//2++//3++    /// increment/decrement
		}
		
		

	}

}
