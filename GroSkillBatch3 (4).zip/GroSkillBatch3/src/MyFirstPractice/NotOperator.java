package MyFirstPractice;

public class NotOperator {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		
		
		
		
		if  (!(a>b))
		{
			System.out.println("Hi");
		}
		
		else
		{
			System.out.println("Hello");
		}
		

	}

}
