package MyFirstPractice;

public class OperatorsEx2 {

	public static void main(String[] args) {
		
		
//		int z=0/10;
//		
//		System.out.println(z);
		
		
		System.out.println(220 >>4); ///180 / 2pow3
		
		

	}

}
