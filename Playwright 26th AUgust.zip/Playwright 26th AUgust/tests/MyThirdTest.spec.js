
import { test, expect } from '@playwright/test';

test.skip('Third playwright test',async({page})=>
{

await page.goto('https://blazedemo.com/');
  await page.locator('select[name="fromPort"]').selectOption('Boston');
  await page.locator('select[name="toPort"]').selectOption('Dublin');
  await page.getByRole('button', { name: 'Find Flights' }).click();
  await page.getByRole('row', { name: 'Choose This Flight 43 Virgin' }).getByRole('button').click();
  await page.getByRole('textbox', { name: 'Name', exact: true }).click();
  await page.getByRole('textbox', { name: 'Name', exact: true }).fill('Harry');
  await page.getByRole('textbox', { name: 'Address' }).click();
  await page.getByRole('textbox', { name: 'Address' }).fill('London');
  await page.getByRole('textbox', { name: 'City' }).click();
  await page.getByRole('textbox', { name: 'City' }).fill('Edinburg');
  await page.getByRole('textbox', { name: 'State' }).click();
  await page.getByRole('textbox', { name: 'State' }).fill('CA');
  await page.getByRole('textbox', { name: 'Zip Code' }).click();
  await page.getByRole('textbox', { name: 'Zip Code' }).fill('43534543');
  await page.locator('#cardType').selectOption('amex');
  await page.getByRole('textbox', { name: 'Credit Card Number' }).click();
  await page.getByRole('textbox', { name: 'Credit Card Number' }).fill('435434353');
  await page.getByRole('textbox', { name: 'Name on Card' }).click();
  await page.getByRole('textbox', { name: 'Name on Card' }).fill('HarryBrook');
  await page.getByRole('button', { name: 'Purchase Flight' }).click();
 
  await expect(page.getByRole('heading', { name: 'Thank you for your purchase' })).toBeVisible();


}
)