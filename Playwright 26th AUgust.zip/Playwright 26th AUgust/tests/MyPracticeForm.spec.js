import { test, expect } from '@playwright/test';

test.only('My Practice Form',async({page})=>
{

    await page.goto("https://demo.automationtesting.in/Register.html");
    console.log(await page.title());

    await expect(page).toHaveTitle("Register");
    console.log("Assertions passed");
   

    const pageTitleVal=await page.locator("//h2").textContent();
    expect (pageTitleVal).toContain("Register")


    
    const fName= await page.locator("[placeholder='First Name']");
    fName.fill("Saurabh");




    const gender=await page.locator("[value='Male']");
    if(gender.isEnabled()==true) 
    {
        gender.click();
    }








    await page.pause();


  







}
)