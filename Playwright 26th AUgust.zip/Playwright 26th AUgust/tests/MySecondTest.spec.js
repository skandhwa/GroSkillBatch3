import { test, expect } from '@playwright/test';

test('second playwright test',async({page})=>
{
await page.goto("https://www.facebook.com");
}
)