// @ts-check
import { defineConfig, devices } from '@playwright/test';

const config=(
{

  testDir: './tests',
  timeout: 30*1000,
  expect:
  {
    timeOut:5000
  },

  reporter: 'html',
 
use:
{
browserName:'chromium',
screenshot :'off',



},







}





);

module.exports=config;




