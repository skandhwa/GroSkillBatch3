package StaticEx;

class Test
{
	int min=10;
	static int max=20;
	
}



public class UsingStaticVariables {

	public static void main(String[] args) {
		
		
		System.out.println(Test.max);
		
		
		Test obj=new Test();
		System.out.println(obj.min);
		

	}

}
