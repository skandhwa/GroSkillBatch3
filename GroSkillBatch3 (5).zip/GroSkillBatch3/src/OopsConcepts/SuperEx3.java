package OopsConcepts;

class Animal
{
	void run()
	{
		System.out.println("Animal runs");
	}
}

class Tiger extends Animal
{
	void run()
	{
		System.out.println("Tiger runs");
	}
}


class Dog extends Animal
{
	void run()
	{
		System.out.println("Dog runs");
	}
	void bark()
	{
		System.out.println("Dog barks");
	}
	
	void test()
	{
		super.run();
		bark();
		run();
	}
	
	
}


public class SuperEx3 {

	public static void main(String[] args) {
		
      Dog obj=new Dog();
      obj.test();
		
		
	}

}
