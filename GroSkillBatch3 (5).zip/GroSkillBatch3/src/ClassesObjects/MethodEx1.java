package ClassesObjects;

class B
{
	void sum(int x,int y,int w)
	{
		int z=x+y+w;
		System.out.println(z);
	}
}



public class MethodEx1 {

	public static void main(String[] args) {
		
		B obj=new B();
		obj.sum(45,78,98);
		
		
		

	}

}
