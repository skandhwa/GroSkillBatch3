package ConditionalStatementsAndLooping;

public class NestedIfStatement {

	public static void main(String[] args) {
		
		int num=20;
		
		if(num<30)
		{
			if(num>15)
			{
				if(num>18)
				{
				
				System.out.println("You are elligible");
				}
			}
		}
		
		
		System.out.println("If nothing printed , please exit");
		

	}

}
