package ConditionalStatementsAndLooping;

public class MultipicationTable {

	public static void main(String[] args) {
		
		int row,col;
		System.out.println("Multipication table is  ");
		
		row=1;
		do
		{
			col=1;
			
			do
			{
				int x=row*col;/// 1*1=1//1*2//1*3
				System.out.print("  "+x);//1//2//3
				col++;///1++//2++//3++//
			}
			while(col<=14);
			System.out.println();
			row++;
			
		}
		
		while(row<=14);
		
		
		
		

	}

}
