package PolymorphismEx;

class P3
{
	
	
	static int sum(int a,int b)
	{
		return a+b;
		
	}
	
	static float sum(int x,int y,float z)
	{
		return x+y+z;
	}
}


public class Ex2 {

	public static void main(String[] args) {
		
	System.out.println(P3.sum(12, 23));	
	
	
		

	}

}
