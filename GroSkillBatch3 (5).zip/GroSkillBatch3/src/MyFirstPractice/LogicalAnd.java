package MyFirstPractice;

public class LogicalAnd {

	public static void main(String[] args) {
		
		
           int a=20;
           int b=30;
           
           
           int max;
           
           max= a>b ? a:b;  /// 20>30 
           
           System.out.println(max);
           
		
		

	}

}
