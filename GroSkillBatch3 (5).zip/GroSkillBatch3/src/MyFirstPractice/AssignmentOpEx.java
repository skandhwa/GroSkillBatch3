package MyFirstPractice;

public class AssignmentOpEx {

	public static void main(String[] args) {
		
		int c=10;
		
		c*=6;
		
		System.out.println(c);
		
		

	}

}
