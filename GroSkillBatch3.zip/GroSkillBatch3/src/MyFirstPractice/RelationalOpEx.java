package MyFirstPractice;

public class RelationalOpEx {

	public static void main(String[] args) {
		
		int a=10;
		if(a==20/2)
		{
			System.out.println("Hello");
		}
		else
		{
			System.out.println("Hi");
		}
		

	}

}
