package ClassesObjects;

public class MySecondObj {

	public static void main(String[] args) {
		
		A obj1=new A();
		obj1.display();
		
		

	}

}
