package CollectionsPractice;

import java.util.HashSet;
import java.util.Set;

public class SetEx3 {

	public static void main(String[] args) {
		
        Set<Integer> s1=new HashSet<Integer>();
		
		s1.add(34);
		s1.add(89);
		s1.add(76);
		s1.add(104);
		
		
Set<Integer> s2=new HashSet<Integer>();
		
		s2.add(34);
		s2.add(89);
		s2.add(16);
		s2.add(94);	
		
		
//		s1.retainAll(s2);
//		System.out.println("Intersection os set is  "+s1);
		
//		s1.removeAll(s2);
//		
//		System.out.println("Difference of set is  "+s1);
		
		s1.containsAll(s2);
		System.out.println(s1);
		
		
		
		
		
		

	}

}
