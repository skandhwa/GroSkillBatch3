package CollectionsPractice;

import java.util.TreeSet;

public class TreeSetEx2 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(45);
		s1.add(12);
		s1.add(98);
		s1.add(6);
		System.out.println("Before polling elements are  "+s1);
		
		s1.pollFirst();
		
		System.out.println(s1);
		
		s1.pollLast();
		System.out.println(s1);
		

	}

}
