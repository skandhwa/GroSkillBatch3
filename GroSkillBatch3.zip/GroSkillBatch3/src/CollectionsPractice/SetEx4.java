package CollectionsPractice;

import java.util.HashSet;
import java.util.Set;

public class SetEx4 {

	public static void main(String[] args) {
		
		int []a= {2,5,7,1,2,5,8,9};
		
		Set<Integer> s1=new HashSet<Integer>();
		
		System.out.println("Elements of set are");
		for(int x:a)
		{
			System.out.print(x+"  ");
		}
		
		
		for(int x:a)
		{
			s1.add(x);
		}
		
		System.out.println("ELements of array after removing duplicates are  "+s1);
		
		
		

	}

}
