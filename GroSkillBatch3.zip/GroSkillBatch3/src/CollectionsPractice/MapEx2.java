package CollectionsPractice;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapEx2 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,"Orange");
		mp.put(4,"Apple");
		mp.put(6,"Kiwi");
		mp.put(7,"Melon");
		mp.put(9,"Banana");
		
		
	String value=	mp.get(9);
	System.out.println("Value at key 9 is "+value);
	
	boolean flag=      mp.containsKey(7);
	System.out.println("does the map contains key 7  "+flag);
	
	boolean flag1=	mp.containsValue("Melon");
	System.out.println("does the map contains value Melon  "+flag1);	
	
//	mp.clear();
//	
//	mp.isEmpty();
	
	mp.remove(7);
	System.out.println(mp);
	
	 Set<Integer> s1=      mp.keySet();
	 System.out.println(s1);
	 
	
		

	}

}
