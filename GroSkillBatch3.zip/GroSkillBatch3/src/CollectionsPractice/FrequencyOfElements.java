package CollectionsPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfElements {

	public static void main(String[] args) {
		
		int []a= {20,10,10,20,40,10,10,20,40};
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int i=0;i<a.length;i++)//i=2,2<9
		{
			if(mp.containsKey(a[i]))//
			{
				mp.put(a[i], (mp.get(a[i])+1));
				
				
				///mp.put(10,2)
				
				///mp.put(10,3)
			}
			
			else
			{
				mp.put(a[i],1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		
		

	}

}
