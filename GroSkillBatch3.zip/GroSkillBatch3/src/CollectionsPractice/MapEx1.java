package CollectionsPractice;

import java.util.HashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,"Orange");
		mp.put(4,"Apple");
		mp.put(6,"Kiwi");
		mp.put(7,"Melon");
		mp.put(9,"Banana");
		mp.put(null, "Papaya");
		mp.put(1, "Lemon");
		mp.put(5, "Lemon");
		mp.put(8, "Lemon");
		
		
		
		System.out.println(mp);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		
		
		
		
		

	}

}
