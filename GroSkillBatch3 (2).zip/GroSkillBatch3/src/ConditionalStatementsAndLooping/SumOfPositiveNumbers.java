package ConditionalStatementsAndLooping;

public class SumOfPositiveNumbers {

	public static void main(String[] args) {
		
		int sum=0;
		int n1=20;
		int n2=30;
		int n3=40;
		
		do
		{
			sum=sum+n1+n2+n3;
		}
		
		while(n1!=0 && n2!=0 && n3!=0);
		
		
		System.out.println("sum is "+sum);
		

	}

}
