package CollectionsPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfWords {

	public static void main(String[] args) {
		
		String str="Tip Toe Tip Tip Tap Tip ";
		String []s=str.split(" ");
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		for(String x:s)
		{
			if(mp.containsKey(x))
			{
				mp.put(x,(mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.print(y.getKey()+" ");
			System.out.println(y.getValue());
		}
		
		int maxFreq=0;
		int minFreq=99999;
		String maxElement=null;
		String minElement=null;
		
		for(Map.Entry<String,Integer> y:mp.entrySet())
		{
			int freq=y.getValue();
			String element=y.getKey();
			
			if(freq>maxFreq)
			{
				maxFreq=freq;
				maxElement=element;
			}
			
			if(freq<minFreq)
			{
				minFreq=freq;
				minElement=element;
			}
			
			
		}
		
		
		System.out.println("Maximum Frequency : "+maxElement+"  "+"->"+maxFreq);
		System.out.println("Minimum Frequency : "+minElement+"  "+"->"+minFreq);
		
		
		
		
		

	}

}
