package CollectionsPractice;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(45);
		s1.add(12);
		s1.add(98);
		s1.add(6);
		
		
		for(int x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("Printing elements in descending order");
		Iterator itr=s1.descendingIterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		

	}

}
