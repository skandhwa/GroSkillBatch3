package CollectionsPractice;

import java.util.HashSet;
import java.util.Set;

public class SetEx1 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new HashSet<Integer>();
		
		s1.add(34);
		s1.add(89);
		s1.add(76);
		s1.add(104);
		
		for(int x:s1)
		{
			System.out.println(x);
		}
		
	int x=	s1.size();
	
	System.out.println("size is  "+x);
	
	boolean flag=    s1.contains(89);
	System.out.println("Does the set contains 89  "+flag);
	
	s1.remove(104);
	
	for(int y:s1)
	{
		System.out.println(y);
	}
		
	
	
		
		
		
		
		

	}

}
