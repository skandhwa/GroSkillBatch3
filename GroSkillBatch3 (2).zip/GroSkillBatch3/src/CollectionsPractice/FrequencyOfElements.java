package CollectionsPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfElements {

	public static void main(String[] args) {
		
		int []a= {20,10,10,20,40,10,10,20,40};
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int i=0;i<a.length;i++)//i=2,2<9
		{
			if(mp.containsKey(a[i]))//
			{
				mp.put(a[i], (mp.get(a[i])+1));
				
				
				///mp.put(10,2)
				
				///mp.put(10,3)
			}
			
			else
			{
				mp.put(a[i],1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
		}
		
		int maxFreq=0;
		int minFreq=99999;
		int maxElement=0;
		int minElement=0;
		
		for(Map.Entry<Integer,Integer> y:mp.entrySet())
		{
			int freq=y.getValue();///freq=3///freq=4///freq=2
			int element=y.getKey();///element=20///element=10///element=40
			
			if(freq>maxFreq)///3>0///4>3//2>4
			{
				maxFreq=freq;///maxFreq=3///maxFreq=4
				maxElement=element;////maxElement=20///maxElement=10
			}
			
			if(freq<minFreq)////3<9999//4<3///2<3
			{
				minFreq=freq;///minFreq=3//minFreq=2
				minElement=element;///minElement=20///minElement=40
			}
			
			
		}
		
		
		System.out.println("Maximum Frequency : "+maxElement+"  "+"->"+maxFreq);
		System.out.println("Minimum Frequency : "+minElement+"  "+"->"+minFreq);
		
		
		
		
		
		
		

	}

}
