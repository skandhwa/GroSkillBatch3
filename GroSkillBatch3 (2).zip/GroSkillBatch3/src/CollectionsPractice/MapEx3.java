package CollectionsPractice;

import java.util.HashMap;
import java.util.Map;

public class MapEx3 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,"Orange");
		mp.put(4,"Apple");
		mp.put(6,"Kiwi");
		mp.put(7,"Melon");
		mp.put(9,"Banana");
		
		
		Map<Integer,String> mp2=new HashMap<Integer,String>();
		mp2.put(1,"Mango");
		mp2.put(4,"Apple");
		mp2.put(11,"Pomegranate");
		mp2.put(14,"Strawberry");
		mp2.put(19,"Pineapple");
		
		
		mp.putAll(mp2);
		
		System.out.println(mp);
		
		mp.remove(4);
		
		
		
		
		
		

	}

}
