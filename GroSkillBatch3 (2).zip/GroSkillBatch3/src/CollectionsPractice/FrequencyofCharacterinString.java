package CollectionsPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofCharacterinString {

	public static void main(String[] args) {
		
		String str="Rradar";
		str=str.toLowerCase();
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		char []ch=str.toCharArray();
		for(char x:ch)
		{
			if(mp.containsKey(x))
			{
				mp.put(x,(mp.get(x)+1));
			}
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.print(y.getKey()+"  ");
			System.out.println(y.getValue());
		}
		
		int maxFreq=0;
		int minFreq=99999;
		char maxElement='\0';
		char minElement='\0';
		
		for(Map.Entry<Character,Integer> y:mp.entrySet())
		{
			int freq=y.getValue();
			char element=y.getKey();
			
			if(freq>maxFreq)
			{
				maxFreq=freq;
				maxElement=element;
			}
			
			if(freq<minFreq)
			{
				minFreq=freq;
				minElement=element;
			}
			
			
		}
		
		
		System.out.println("Maximum Frequency : "+maxElement+"  "+"->"+maxFreq);
		System.out.println("Minimum Frequency : "+minElement+"  "+"->"+minFreq);
		
		
		
		
		
		

	}

}
