package CollectionsPractice;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx {

	public static void main(String[] args) {
		
		
		Set<String> s1=new HashSet<String>();
		s1.add("apple");
		s1.add("watermelon");
		s1.add("banana");
		s1.add("kiwi");
		
		Iterator itr=s1.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		

	}

}
