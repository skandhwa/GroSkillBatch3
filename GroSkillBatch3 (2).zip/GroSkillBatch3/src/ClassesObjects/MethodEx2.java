package ClassesObjects;

class C
{
	int mul(int a,int b,int c)
	{
		int result= a*b*c;
		return result;
	}
	
	float divide(int x,int y)
	{
		int z=x/y;
		return z;
	}
	
	
}



public class MethodEx2 {

	public static void main(String[] args) {
		
		C obj=new C();
	System.out.println(obj.mul(12, 13, 14));	
	
	System.out.println(obj.divide(40,5))	;
		
		
		

	}

}
