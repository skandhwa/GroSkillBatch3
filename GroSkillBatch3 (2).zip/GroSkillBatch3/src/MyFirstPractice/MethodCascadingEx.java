package MyFirstPractice;

class D1
{
	void display()
	{
		System.out.println("Hello");
	}
}

class D2 extends D1
{
	void test()
	{
		System.out.println("Hi");
	}
	
	void message()
	{
		System.out.println("Welcome");
	}
	
	void run()
	{
		test();
		message();
	}
	
	
}


public class MethodCascadingEx {

	public static void main(String[] args) {
		
		D2 obj=new D2();
		obj.run();
		
		

	}

}
