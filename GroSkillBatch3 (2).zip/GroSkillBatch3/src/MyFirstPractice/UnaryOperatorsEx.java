package MyFirstPractice;

public class UnaryOperatorsEx {

	public static void main(String[] args) {
		
		int a=5;
		
		int b=7;
		
		int c= 9; 
		
		
		int sum= a++  - c--  +  ++b   -  ++a  +  --c  + --b;
		
		
		// 5 - 9 + 8 - 7 + 7 + 7
		
		
		// a=7, c=7 , b=7
		
		
		
		
		System.out.println(sum);
		
		
		
		
		
		
		
		
		

	}

}
