package UsingSwitchCase;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		
		System.out.println("Enter your marks");
		Scanner sc=new Scanner(System.in);
		int marks=sc.nextInt();
		
		switch(marks)
		
		{
		
		case A
		
		
		}
		
		
		
		

	}

}
