package ConstantData;

public class ConstantsDataPath {
	
	public final static String PROPFILEPATH="src\\main\\java\\Global.properties";
    public final static String EXCELPATH="src\\main\\java\\TestData\\TestData31stJuly.xlsx"; 
}
