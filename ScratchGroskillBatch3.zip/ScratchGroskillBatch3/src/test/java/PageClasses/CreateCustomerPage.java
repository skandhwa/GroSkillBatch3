package PageClasses;

public class CreateCustomerPage {
	
	public  String cusName()
	{
		String cusName="//input[@name='name']";
		return cusName;
	}
	
	public  String gender()
	{
		String gender="//input[@name='rad1' and @value='m']";
		return gender;
	}
	
	public String dOB()
	{
		String doB="//input[@name='dob']";
		return doB;
	}
	
	
	public String address()
	{
		String address="//textarea[@name='addr']";
		return address;
	}
	
	public String city()
	{
		String city="//input[@name='city']";
		return city;
	}
	
	public String state()
	{
		String state="//input[@name='state']";
		return state;
	}
	
	public String pin()
	{
		String pin="//input[@name='pinno']";
		return pin;
	}
	
	public String mobile()
	{
		String mobile="//input[@name='telephoneno']";
		return mobile;
	}
	
	public String email()
	{
		String email="//input[@name='emailid']";
		return email;
	}
	
	public String password()
	{
		String password="//input[@name='password']";
		return password;
	}
	
	
	public String submit()
	{
		String submit="//input[@name='sub']]";
		return submit;
	}

}
