package TestClasses;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PageClasses.LoginPage;
import Utilities.DriverInitialization;
import Utilities.FetchDataFromExcel;

public class LoginTest {
	
	LoginPage obj=new LoginPage();
	FetchDataFromExcel ex1=new FetchDataFromExcel();
	WebDriver driver1=DriverInitialization.getDriver();
	
	
	@BeforeMethod(alwaysRun=true)
	public void openBrowser()
	{
		
		driver1.manage().window().maximize();
	}
	
	@Test
	public void loginApplication() throws IOException
	{
		driver1.findElement(By.xpath(obj.enterUserID())).sendKeys(ex1.getValueExcel(1, 0));
		driver1.findElement(By.xpath(obj.enterPassword())).sendKeys(ex1.getValueExcel(1, 1));
		driver1.findElement(By.xpath(obj.loginBtn())).click();
		
	}
	
	
	@AfterMethod(alwaysRun=true)
	public void closeBrowser()
	{
		driver1.quit();
	}
	
	
	

}
