package TestClasses;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utilities.DriverInitialization;

public class CreateCustomerTest extends LoginTest {
	
	WebDriver driver1=DriverInitialization.getDriver();
	
	@DataProvider(name="dp1")
	public Object[][] dpmethod()
	{
	return new Object[][]
	{
	{"Harry","17-05-1995","LajpatNagar","Delhi","NCR","700055","9765423145","vgtrec@gmail.com","abygUmA"},
	{"John","13-04-1993","Bandra","Mumbai","Maharastra","300045","8764423145","rtbgtrec@gmail.com","abygUmA"}
	
	};
	}
	
	@BeforeMethod(alwaysRun=true)
	public void openBrowser()
	{
		
		driver1.manage().window().maximize();
	}
	
	@Test(dataProvider="dp1")
	public void createCustomer() throws IOException
	{
		loginApplication();
		
		
		
	}
		
	
	
	

}
