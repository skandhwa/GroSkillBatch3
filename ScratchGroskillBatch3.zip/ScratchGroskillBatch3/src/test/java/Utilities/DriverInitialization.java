package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverInitialization {
	
	public static WebDriver driver;
	public static String browserName=FetchDataFromProperty.readDataFromProperty().getProperty("browser");
	public static String URL=FetchDataFromProperty.readDataFromProperty().getProperty("url");
	
	
	public static WebDriver getDriver()
	{
		if(browserName.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			driver.get(URL);
		}
		
		else if(browserName.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			driver.get(URL);
		}
		else if(browserName.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			driver.get(URL);
		}
		
		return driver;
	}
	
	
	
	

}
