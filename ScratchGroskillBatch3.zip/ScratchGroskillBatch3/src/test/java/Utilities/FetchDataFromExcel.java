package Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import ConstantData.ConstantsDataPath;

public class FetchDataFromExcel {
	
	
	public static String getValueExcel(int x,int y) throws IOException
	{
		FileInputStream fs=new FileInputStream(ConstantsDataPath.EXCELPATH);
		XSSFWorkbook wb=new XSSFWorkbook(fs);
		XSSFSheet sheet=wb.getSheetAt(0);
		XSSFCell cellvalue= sheet.getRow(x).getCell(y);
		String value=cellvalue.toString();
		return value;
		
		
	}

}
