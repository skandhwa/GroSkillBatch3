package Default1;

public class Ex2 extends Ex1 {

	public static void main(String[] args) {
		
		Ex2 obj=new Ex2();
		obj.display();
		

	}

}
