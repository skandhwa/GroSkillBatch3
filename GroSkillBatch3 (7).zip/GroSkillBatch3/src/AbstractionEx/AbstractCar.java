package AbstractionEx;


abstract class Car
{
	abstract void gearPrinciple();
	abstract void clutchInternalArchitecture();
	abstract void accleratorWorkingPrinciple();
	
}






public class AbstractCar {

	public static void main(String[] args) {
		

	}

}
