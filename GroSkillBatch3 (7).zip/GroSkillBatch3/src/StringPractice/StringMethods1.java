package StringPractice;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="Hello";
		int x=str.length();
		System.out.println("The length of String is  "+x);
		
	char ch=	str.charAt(4);
	System.out.println("value is "+ch);
		
		
		

	}

}
