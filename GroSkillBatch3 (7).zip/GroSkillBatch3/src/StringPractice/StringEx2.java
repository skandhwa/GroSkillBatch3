package StringPractice;

public class StringEx2 {

	public static void main(String[] args) {
		
		String str2=new String("Hello");
		
		
		

	}

}
