package StringPractice;

public class StringReplaceAndReplaceAll {

	public static void main(String[] args) {
		
		String str="Hello Java";
		
		str=str.replaceAll('e', 'a');
		System.out.println(str);
		

	}

}
