package StringPractice;

import java.util.Arrays;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
	char []ch=	str.toCharArray();
	
	
	System.out.println(ch);
	
	
		

	}

}
