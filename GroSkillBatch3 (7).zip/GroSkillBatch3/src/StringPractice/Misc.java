package StringPractice;

public class Misc {

	public static void main(String[] args) {
		
		String str="   Hello   ";
	str=	str.toLowerCase();
	
	System.out.println(str);
	
	str= str.trim();
	
	System.out.println(str);
		

	}

}
