package ArrayEx;

public class ArraySorting {

	public static void main(String[] args) {
		
		int []a= {12,6,8,14,19,2};
		for(int i=0;i<a.length;i++)//i=0,0<6//i=1,1<6
		{
			for(int j=i+1;j<a.length;j++)//j=2,2<6
			{
				if(a[i]>a[j])///a[0]>a[5]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			System.out.print(a[i]+"  ");
		}
		
		
		

	}

}
