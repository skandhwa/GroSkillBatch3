package ArrayEx;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int []a= {12,76,98,103,67};
		
		int sum=0;
		
		for(int i=1;i<a.length;i++)//i=0,0<5///i=1,1<5
		{
			sum=sum+a[i];////sum=0+12=12///sum=12+76=88//
		}
		
		
		for(int x:a)
		{
			sum=sum+x;
		}
		
		
		System.out.println(sum);
		

	}

}
