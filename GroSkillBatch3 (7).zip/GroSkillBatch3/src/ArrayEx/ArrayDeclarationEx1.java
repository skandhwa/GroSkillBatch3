package ArrayEx;

public class ArrayDeclarationEx1 {

	public static void main(String[] args) {
		
		int []a= {12,45,67,89,90};
		
		int []b=new int[5];
		b[0]=12;
		b[1]=15;
		b[2]=34;
		b[3]=67;
		b[4]=89;
		
		
		for(int i=0;i<a.length;i++)///i=0,0<5/// i=1,1<5
		{
			System.out.println(a[i]);///a[0]//a[1]
		}
		
		
		for(int x:b)
		{
			System.out.println(x);
		}
		
		
		
		
		
		
		

	}

}
