package ArrayEx;

import java.util.Arrays;

public class ArrayMethodsEx4 {

	public static void main(String[] args) {
		int a[]= {643,345,467,289,400};
		Arrays.toString(a);
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		

	}

}
