package StaticEx;

class X4
{
	static int cube(int x)
	{
		return x*x*x;
	}
}


public class StaticMethods3 {

	public static void main(String[] args) {
		
	System.out.println(X4.cube(5));	
		

	}

}
