package StaticEx;

class X2
{
	static int a=10;
	static int b=20;
	
	static int sum()
	{
		return a+b;
	}
	
}

public class StaticMethodEx {

	public static void main(String[] args) {
		
		
	System.out.println("The sum is  "+X2.sum());	
		

	}

}
