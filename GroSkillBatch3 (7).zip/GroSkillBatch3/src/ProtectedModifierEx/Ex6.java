package ProtectedModifierEx;

public class Ex6 {
	
	protected void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		
		
		

	}

}
