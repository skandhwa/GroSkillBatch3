package ProtectedModifierEx;

public class Ex3 {

	public static void main(String[] args) {
		
		
		P4 obj=new P4();
		obj.display();

	}

}
