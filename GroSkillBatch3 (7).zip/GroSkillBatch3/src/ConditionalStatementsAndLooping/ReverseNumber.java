package ConditionalStatementsAndLooping;

public class ReverseNumber {

	public static void main(String[] args) {
		
		int num=121;
		int rev=0;
		
		int n=num;
		
		while(num>0)///12>0  ///1>0
		{
			int r=num%10;///r=125%10=5   /// r=2  ///r=1%10=1
			rev =(rev*10)+r;///0*10+5=5//rev=5*10+2=52///rev=52*10+1=521
			num=num/10;//num=12///num=12/10=1///num=1/10=0
			
		}
		
		System.out.println("Reverse is "+rev);
		
		
		if(n==rev)
		{
			System.out.println("The number is plaindrome");
		}
		
		else
		{
			System.out.println("Not plaindrome");
		}
		

	}

}
