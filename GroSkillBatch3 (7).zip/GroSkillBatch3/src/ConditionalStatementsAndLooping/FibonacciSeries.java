package ConditionalStatementsAndLooping;

public class FibonacciSeries {

	public static void main(String[] args) {
		
		int n1=0,n2=1;
		int n=10;
		
		System.out.print("Printing Fibonacci Series");
         System.out.print("  "+n1+"   "+n2+"  ");
		for(int i=2;i<=n;i++)///i=2,2<=10//3<=10//4<=10//
		{
			int n3=n1+n2;//n3=0+1=1// n3=1+1=2 //n3=1+2=3
			n1=n2;//n1=1//n1=1//n1=2
			n2=n3;//n2=1//n2=2//n2=3
			System.out.print("  "+n3+"  ");
		}
		

	}

}
