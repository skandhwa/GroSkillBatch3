package ConditionalStatementsAndLooping;

public class doWhile {

	public static void main(String[] args) {
		
		int i=1;
		
		do
		{
			System.out.println(i);//1///2
			i++;//1++//2++
		}
		 while(i<23%5);//2<3///3<3
		
		
		
		

	}

}
