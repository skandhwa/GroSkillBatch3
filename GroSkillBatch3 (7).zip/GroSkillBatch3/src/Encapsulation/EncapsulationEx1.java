package Encapsulation;

class Test
{
	private int x=5;
	private int y=10;
	
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	
	
}





public class EncapsulationEx1 {

	public static void main(String[] args) {
		
		Test obj=new Test();
	System.out.println(obj.getX());	
		

	}

}
