package PrivateAccessModifier;

class T2
{
	private void display()
	{
		System.out.println("Hello");
	}
}



public class Ex1 {
	
	private int x=10;
	
	
	
	

	public static void main(String[] args) {
		
		Ex1 obj=new Ex1();
	System.out.println(obj.x);	
	
	
	T2 obj1=new T2();
	obj1.display();
		
		
		

	}

}
