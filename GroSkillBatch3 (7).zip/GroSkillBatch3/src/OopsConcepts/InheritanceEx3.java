package OopsConcepts;

class I6
{
	void test()
	{
		System.out.println("Hi");
	}
}

class I7 extends I6
{
	void message()
	{
		System.out.println("Hello");
	}
}

class I8 extends I6
{
	void test2()
	{
		System.out.println("How r u");
	}
}







public class InheritanceEx3 {

	public static void main(String[] args) {
		
		I8 obj=new I8();
		obj.test();
		//obj.message();
		obj.test2();
		
		
		

	}

}
