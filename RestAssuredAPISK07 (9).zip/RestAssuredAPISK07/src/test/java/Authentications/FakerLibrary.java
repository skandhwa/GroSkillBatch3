package Authentications;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.HashMap;
import java.util.Map;

import com.github.javafaker.Faker;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class FakerLibrary {

	public static void main(String[] args) {
		
		 Faker faker = new Faker();
		String name = faker.name().fullName();
        String email = faker.internet().emailAddress();
        String phone = faker.phoneNumber().cellPhone();
              

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("name", name);
        requestBody.put("email", email);
        requestBody.put("phone", phone);
        
        
        
        RestAssured.baseURI="https://reqres.in";
        		
        		Response res=		given().log().all().headers("x-api-key","reqres-free-v1")
                .headers("Content-Type","application/json")
	.body(requestBody)
	.when().post("api/users")
	.then().log().all().statusCode(201).
	extract().response();
        		
        		System.out.println(res.asString());
        		
        		
        		
        

        

	}

}
