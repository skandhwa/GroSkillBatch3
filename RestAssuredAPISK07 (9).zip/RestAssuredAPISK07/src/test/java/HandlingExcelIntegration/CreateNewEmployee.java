package HandlingExcelIntegration;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateNewEmployee {

	public static void main(String[] args) throws IOException {
		
		FetchDataFromExcel obj=new FetchDataFromExcel(ConstantData.ExcelPath,ConstantData.SheetName);
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name",FetchDataFromExcel.getData(1, 0));
		mp.put("job",FetchDataFromExcel.getData(1, 1));
		mp.put("id",FetchDataFromExcel.getData(1, 2));
		mp.put("salary",FetchDataFromExcel.getData(1, 3));
		
		
		
		RestAssured.baseURI="https://reqres.in";
		
		Response res=		given().log().all().headers("x-api-key","reqres-free-v1")
                .headers("Content-Type","application/json")
	.body(mp)
	.when().post("api/users")
	.then().log().all().statusCode(201).
	extract().response();
		
		String Response=res.asString();
		System.out.println("Response Value is   "+Response);
		
		
		
		
		

	}

}
