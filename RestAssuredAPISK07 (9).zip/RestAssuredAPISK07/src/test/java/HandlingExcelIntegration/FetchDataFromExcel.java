package HandlingExcelIntegration;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FetchDataFromExcel {
	
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	
	FetchDataFromExcel(String excelPath,String sheetName) throws IOException
	{
		workbook=new XSSFWorkbook(excelPath);
		sheet=workbook.getSheet(sheetName);
		
	}
	
	
	public static Object getData(int x,int y)
	{
		DataFormatter formatter=new DataFormatter();
	    Object value=formatter.formatCellValue(sheet.getRow(x).getCell(y));
	    return value;
		
	}
	
	
	

	
		
//		XSSFWorkbook workbook=new XSSFWorkbook("E:/TestData15thJuly.xlsx");
//		XSSFSheet sheet=workbook.getSheet("Sheet1");
//	String value=sheet.getRow(1).getCell(0).toString();	
//	System.out.println(value);
	
		

	}


