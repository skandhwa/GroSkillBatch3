package HandlingExcelIntegration;

public class ConstantData {
	
	public static final String ExcelPath="E:/TestData15thJuly.xlsx";
	public static final String SheetName="Sheet1";
	

}
