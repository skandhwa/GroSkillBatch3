package HandlingDBConnection;

public class SqlQueries {
	
	public static String myquery1()
	{
		String query1="select * from julydemo.employee limit 1";
		return query1;
	}
	
	

}
