package POJOEx4;

import java.util.List;

public class EmployeePOJO4 {
	
	private String name;
	private int id;
	private float salary;
	private EmployeeAddressPOJO4 x;
	private List<String> banks;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public EmployeeAddressPOJO4 getX() {
		return x;
	}
	public void setX(EmployeeAddressPOJO4 x) {
		this.x = x;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	
	
	
	
	
	
	
	

}
