package POJOEx4;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreateEmployee4 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddressPOJO4 empAddress=new EmployeeAddressPOJO4();
		empAddress.setCity("Delhi");
		empAddress.setState("NCR");
		empAddress.setZip(713304); 
		
		List<String> banks=new ArrayList<String>();
		banks.add("SBI");
		banks.add("HDFC");
		banks.add("ICICI");
		
		EmployeePOJO4 emp=new EmployeePOJO4();
		emp.setId(4567);
		emp.setName("Saurabh");
		emp.setSalary(90000f);
		emp.setX(empAddress);
		emp.setBanks(banks);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		
		
		

	}

}
