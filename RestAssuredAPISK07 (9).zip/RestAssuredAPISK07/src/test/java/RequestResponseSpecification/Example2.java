package RequestResponseSpecification;
import static io.restassured.RestAssured.given;

import PayloadData.Payload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Example2 {

	public static void main(String[] args) {
		
		
		
		
		
		RequestSpecification respec=given().log().all().spec(ReqResCommon.getRequest()).
				header("x-api-key","reqres-free-v1")
				.body(Payload.addEmployeeDetails("Tom", "Manager"));
		
		
			
		
		
		String response=respec.when().post("api/users").then().log().all().
				spec(ReqResCommon.getResponse(201)).extract().
				response().asString();
		
		
		System.out.println(response);
				
                                  		
		
		

	}

}
