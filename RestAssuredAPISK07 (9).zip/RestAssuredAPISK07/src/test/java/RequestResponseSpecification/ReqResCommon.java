package RequestResponseSpecification;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReqResCommon {
	
	public static RequestSpecification getRequest()
	{
		RequestSpecification req=new RequestSpecBuilder()
				.setBaseUri("https://reqres.in/")
				.setRelaxedHTTPSValidation()
				.setContentType(ContentType.JSON)
				.build();
		
		return req;
	}
	
	
	public static ResponseSpecification getResponse(int code)
	{
		ResponseSpecification respec=new ResponseSpecBuilder()
				.expectContentType(ContentType.JSON)
				.expectStatusCode(code).expectHeader("Connection","keep-alive")
				.build();
		
		return respec;
	}
	
	

}
