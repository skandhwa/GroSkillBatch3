package RequestResponseSpecification;

import static io.restassured.RestAssured.given;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class Example1 {

	public static void main(String[] args) {

		
		
		
		RequestSpecification res=given().log().all().spec(ReqResCommon.getRequest()).queryParam("page",2);
		
  	    Response response=res.when().get("api/users").then().log().all().
				spec(ReqResCommon.getResponse(200))
				.extract().response();
		
		
		long time=response.getTime();
	
		
		String responseString=response.asString();
		
		System.out.println(responseString);
		
		JsonPath js=new JsonPath(responseString);
		
		
		
		
		
		

	}

}
