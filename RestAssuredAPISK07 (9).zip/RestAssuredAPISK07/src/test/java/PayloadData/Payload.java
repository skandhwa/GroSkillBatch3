package PayloadData;

public class Payload {
	
	
	public static String addEmployeeDetails(String empName,String jobRole)
	{
		
		String emp="{\r\n"
				+ "    \"name\": \""+empName+"\",\r\n"
				+ "    \"job\": \""+jobRole+"\"\r\n"
				+ "}";
		
		return emp;
		
		
		
		
	}
	
	public static String bookDetails(String isbn,String aisle,String author)
	{
		String bookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\""+author+"\"\r\n"
				+ "}";
		
		return bookData;
	}
	
	public static String xmlPayloadData()
	{
		String payloadData="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
				+ "<Pet>\r\n"
				+ "	<id>0</id>\r\n"
				+ "	<Category>\r\n"
				+ "		<id>0</id>\r\n"
				+ "		<name>string</name>\r\n"
				+ "	</Category>\r\n"
				+ "	<name>doggie</name>\r\n"
				+ "	<photoUrls>\r\n"
				+ "		<photoUrl>string</photoUrl>\r\n"
				+ "	</photoUrls>\r\n"
				+ "	<tags>\r\n"
				+ "		<Tag>\r\n"
				+ "			<id>0</id>\r\n"
				+ "			<name>string</name>\r\n"
				+ "		</Tag>\r\n"
				+ "	</tags>\r\n"
				+ "	<status>available</status>\r\n"
				+ "</Pet>";
		
		return payloadData;
	}
	
	
	
	
	
	
	

}
