package POJOEx3;

import java.util.ArrayList;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.RestAssured.*;
import static io.restassured.RestAssured.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		EmployeePOJO3 emp=new EmployeePOJO3();
		
		emp.setName("Harry");
		emp.setAge(45);
		emp.setSalary(80000f);
		emp.setMarried(false);
		
		
EmployeePOJO3 emp1=new EmployeePOJO3();
		
		emp1.setName("Matt");
		emp1.setAge(35);
		emp1.setSalary(90000f);
		emp1.setMarried(true);
		
		
EmployeePOJO3 emp2=new EmployeePOJO3();
		
		emp2.setName("Lloyd");
		emp2.setAge(55);
		emp2.setSalary(70000f);
		emp2.setMarried(false);	
		
		
		List<EmployeePOJO3> li=new ArrayList<EmployeePOJO3>();
		li.add(emp);
		li.add(emp1);
		li.add(emp2);
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
		
	
	RestAssured.baseURI="https://reqres.in";
String Response=	given().log().all().body(empJSON).headers("content-type","application/json")
	.header("x-api-key","reqres-free-v1")
	.when().post("api/users")
	.then().assertThat().statusCode(201)
	.extract().response().asString();

System.out.println("The Response is  "+Response);
	
		
		
		
		
		
		
		

	}

}
