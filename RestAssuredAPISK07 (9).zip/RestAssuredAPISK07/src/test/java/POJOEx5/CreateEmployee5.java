package POJOEx5;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee5 {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		
		List<String> landmark=new ArrayList<String>();
		landmark.add("ABC sweets");
		landmark.add("GK hotel");
		landmark.add("JK mall");
		
		HouseDetailsPOJO hPojo=new HouseDetailsPOJO();
		hPojo.setFlatNo(304);
		hPojo.setStreet("HallmarkStreet");
		hPojo.setLandmark(landmark);
		
		EmployeeAddress5 empAdd5=new EmployeeAddress5();
		empAdd5.setCity("Hyderabad");
		empAdd5.setState("telangana");
		empAdd5.setHdpojo(hPojo);
		empAdd5.setZip(78654);
		
		List<String> bank=new ArrayList<String>();
		bank.add("SBI");
		bank.add("HDFC");
		bank.add("ICICI");
		
		EmployeePOJO5 empPojo=new EmployeePOJO5();
		empPojo.setName("Harry");
		empPojo.setAge(47);
		empPojo.setSalary(90000);
		empPojo.setBanks(bank);	
		empPojo.setEmpAddPojo(empAdd5);
		
		ObjectMapper obj=new ObjectMapper();
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(empPojo);
			
		
		RestAssured.baseURI="https://reqres.in";
	String Response=	given().log().all().body(empJSON).headers("content-type","application/json")
		.header("x-api-key","reqres-free-v1")
		.when().post("api/users")
		.then().assertThat().statusCode(201)
		.extract().response().asString();

	System.out.println("The Response is  "+Response);
		
		
		
		
		
		
		
		

	}

}
