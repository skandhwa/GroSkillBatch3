package POJOEx5;

import java.util.List;

public class EmployeePOJO5 {
	
	private String name;
	private int age;
	private double salary;
	private EmployeeAddress5 empAddPojo;
	private List<String> banks;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public EmployeeAddress5 getEmpAddPojo() {
		return empAddPojo;
	}
	public void setEmpAddPojo(EmployeeAddress5 empAddPojo) {
		this.empAddPojo = empAddPojo;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	
	
	

}
