package POJOEx2;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import POJOEx1.EmployeeData;
import io.restassured.RestAssured;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException {
		
		AdressPojo2 x=new AdressPojo2();
		
		x.setCity("Delhi");
		x.setStreet("MG road");
		x.setZipcode(713308);
		
		EmployeePojo2 empObj=new EmployeePojo2();
		empObj.setId(67543);
		empObj.setMarried(false);
		empObj.setName("John");
		empObj.setSalary(987557f);
		empObj.setEmpaddress(x);
		
		ObjectMapper obj=new ObjectMapper();
		RestAssured.baseURI="https://reqres.in";
		
		String empJson=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(empObj);
		
		String Response=	given().log().all().body(empJson).headers("x-api-key","reqres-free-v1")
		.header("Content-type","application/json")
			.when().post("api/users").then().log().all().
			assertThat().statusCode(201)
			.extract().response().asString();

		System.out.println(Response);
		
		
		System.out.println("Doing Desrialization");


		EmployeePojo2 empObj1=obj.readValue(empJson, EmployeePojo2.class);


		int id=empObj1.getId();
		System.out.println("Id of Employee is  "+id);


		
		
		
		
		
		
		

	}

}
