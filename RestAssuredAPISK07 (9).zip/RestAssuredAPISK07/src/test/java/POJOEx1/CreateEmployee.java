package POJOEx1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;


public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		RestAssured.baseURI="https://reqres.in";
		
		EmployeeData emp=new EmployeeData();
		emp.setId(34567);
		emp.setName("Harry");
		emp.setSalary(80000f);
		emp.setMarried(true);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJson=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
String Response=	given().log().all().body(empJson).headers("x-api-key","reqres-free-v1")
.header("Content-type","application/json")
	.when().post("api/users").then().log().all().
	assertThat().statusCode(201)
	.extract().response().asString();

System.out.println(Response);


System.out.println("Doing Desrialization");


EmployeeData empObj=obj.readValue(Response, EmployeeData.class);


int id=empObj.getId();
System.out.println("Id of Employee is  "+id);






		
		
		
		
		
		
		
		
		
		

	}

}
