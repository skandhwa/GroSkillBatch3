package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import PayloadData.Payload;

public class HandlingXMlData {

	public static void main(String[] args) {
	
		RestAssured.baseURI="https://petstore.swagger.io";
	String Response=	given().log().all().body(Payload.xmlPayloadData()).header("content-type","application/xml")
		.when().post("v2/pet").
		then().log().all().
		assertThat().statusCode(200)
		.extract().response().asString();
		
		System.out.println(Response);

	}

}
