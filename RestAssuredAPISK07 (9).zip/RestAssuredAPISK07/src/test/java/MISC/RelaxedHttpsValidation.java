package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class RelaxedHttpsValidation {

	public static void main(String[] args) {
		
		
		//RestAssured.baseURI="https://self-signed.badss1.com/";
	String Response=	given().log().all().relaxedHTTPSValidation("SSL")
        .when().get("https://self-signed.badssl.com/").then().extract().response().asString();
		
	System.out.println(Response);	
		

	}

}
