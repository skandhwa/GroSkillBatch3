package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class HandlingFileInput {

	public static void main(String[] args) {
		
		String f="D:\\RandomDataGeneration.txt";
		
		RestAssured.baseURI="http://httpbin.org";
		
	String Response=	given().log().all().
		headers("Content-Type","multipart/form-data")
		.multiPart("File",f)
		.when().post("post")
		.then().log().all().extract().response().asString();
		
		System.out.println(Response);
		
		

	}

}
