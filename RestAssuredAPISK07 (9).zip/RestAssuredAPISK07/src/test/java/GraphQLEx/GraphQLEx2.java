package GraphQLEx;

import static io.restassured.RestAssured.given;

import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class GraphQLEx2 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://countries.trevorblades.com/";
		
		String query="query {\r\n"
				+ "  countries {\r\n"
				+ "    code\r\n"
				+ "    name\r\n"
				+ "    capital\r\n"
				+ "    currency\r\n"
				+ "  }\r\n"
				+ "}";
		
		
		JSONObject payload=new JSONObject();
		
		payload.put("query", query);
		
		String reqPayload=payload.toString();
		
		
	String Response=	given().log().all().header("content-type","application/json")
		.body(reqPayload).when().post()
		.then().log().all().extract().response().asString();
		
		
		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
		
		System.out.println();
		System.out.println();
		System.out.println();
		
	String Currency=	js.getString("data.countries[3].currency");
	
	System.out.println(Currency);
		
		
		
		
		

	}

}
