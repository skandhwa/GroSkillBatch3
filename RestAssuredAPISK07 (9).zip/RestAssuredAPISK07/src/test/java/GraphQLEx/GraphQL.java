package GraphQLEx;

import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GraphQL {

	public static void main(String[] args) {
		
		
		 String query = """
	                query {
             country(code: "CH") {
               name
               capital
               currency
             }
           }
           """;

	        // Build JSON payload
	        JSONObject payload = new JSONObject();
	        payload.put("query", query);

	        // Send POST request
	        Response response = RestAssured.given()
	                .baseUri("https://countries.trevorblades.com/")
	                .header("Content-Type", "application/json")
	                .body(payload.toString())
	                .when()
	                .post();

	        // Print response
	        System.out.println("Status Code: " + response.getStatusCode());
	        System.out.println("Response:\n" + response.prettyPrint());

	        // Validate response fields
	        String name = response.jsonPath().getString("data.country.name");
	        String capital = response.jsonPath().getString("data.country.capital");
	        String currency = response.jsonPath().getString("data.country.currency");

	        System.out.println("\nParsed Response:");
	        System.out.println("Country Name: " + name);
	        System.out.println("Capital: " + capital);
	        System.out.println("Currency: " + currency);
	    }
	}

	


