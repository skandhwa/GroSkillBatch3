package HandlingCookies;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class ProgramCookies {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://httpbin.org";
		
	String Response=	given().log().all().cookies(CookiesData.SetCookieData())
		.when().get("get")
		.then().log().all().
		extract().response().asString();
	
	System.out.println(Response);
		
		
		
		
		
		
		

	}

}
