package OopsConcepts;

class S2
{
	String colour="red";
	void display()
	{
		System.out.println("hello");
	}
}

class S3 extends S2
{
	String color="green";
	void test()
	{
		System.out.println(color);
		System.out.println("Hi");
	}
}

class S4 extends S3
{
	String color="yellow";
	void message()
	{
		System.out.println(color);
		System.out.println(super.color);
	}
}



public class SuperEx2 {

	public static void main(String[] args) {
		
		
		S4 obj=new S4();
		obj.test();
		obj.display();
		obj.message();
		
		

	}

}
