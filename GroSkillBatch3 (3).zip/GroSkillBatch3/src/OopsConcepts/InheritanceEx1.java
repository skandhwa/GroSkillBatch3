package OopsConcepts;

class I1
{
	void display()
	{
		System.out.println("Hello");
	}
}

class I2 extends I1
{
	void test()
	{
		System.out.println("Hi");
	}
}

public class InheritanceEx1 {

	public static void main(String[] args) {
		
		I1 obj=new I1();
		
		
		obj.display();
		
		
		

	}

}
