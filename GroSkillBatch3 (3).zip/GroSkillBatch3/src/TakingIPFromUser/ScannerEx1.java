package TakingIPFromUser;

import java.util.Scanner;

public class ScannerEx1 {

	public static void main(String[] args) {
		
		int x;
		int y;
		
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of x");
		x=sc.nextInt();
		System.out.println("Enter the value of y");
		y=sc.nextInt();
		
		int z=x+y;
		System.out.println("The sum is  "+z);
		
		
		
		
		

	}

}
