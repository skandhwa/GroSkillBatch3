package ThisKeywordEx;

class X7
{
	int id;
	String name;
	float salary;
	boolean m;
	
	X7(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	
	X7(int id,String name,float salary,boolean m)
	{
		this(id,name,salary);
		this.m=m;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+salary+"  "+m );
	}
}



public class ThisEx3 {

	public static void main(String[] args) {
		
		X7 obj=new X7(1234,"Mahesh",80000f);
		obj.display();
		X7 obj1=new X7(9234,"Ramesh",90000f,true);
		obj1.display();

	}

}
