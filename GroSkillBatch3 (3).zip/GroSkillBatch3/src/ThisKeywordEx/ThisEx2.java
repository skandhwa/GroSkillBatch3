package ThisKeywordEx;

class X6
{
	static int x=20;
	
	static void display()
	{
		int x=40;
		//System.out.println(this.x); //// static will not work with this so will give error
		System.out.println(x);
	}
	
}



public class ThisEx2 {

	public static void main(String[] args) {
		
		X6 obj=new X6();
		obj.display();
	

	}

}
