package CollectionsEx;

import java.util.Vector;

public class VectorEx1 {

	public static void main(String[] args) {
	
		Vector<String> v=new Vector<String>();
		v.add("lemon");
		v.add("brinjal");
		v.add("potato");
		
		for(String x:v)
		{
			System.out.println(x);
		}
		

	}

}
