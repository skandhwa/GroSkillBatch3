package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx2 {

	public static void main(String[] args) {
		
		ArrayList<Object> li=new ArrayList<>();
		li.add(45);
		li.add(78.5f);
		li.add("Saurabh");
		li.add(true);
		
		ArrayList<Object> li2=new ArrayList<>();
		li2.add(451);
		li2.add(98.5f);
		li2.add("Gaurabh");
		li2.add(false);
		
		
		li.addAll(li2);
		
		System.out.println(li);
		
		
		
		
		
		
		
		
		
		

	}

}
