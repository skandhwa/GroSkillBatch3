package CollectionsEx;

import java.util.ArrayList;

public class ArrayListEx5 {

	public static void main(String[] args) {
		ArrayList<String> li=new ArrayList<String>();
		li.add("apple");
		li.add("Kiwi");
		li.add("banana");
		li.add("orange");
		
		
		System.out.println(li);
//		li.clear();
//		System.out.println("After clearing elements are  "+li);
		
//		li.remove(2);
//		System.out.println("After removing element from 2nd index "+li);
		
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("pineapple");
		li2.add("lemon");
		li2.add("banana");
		li2.add("orange");
		
//		li.containsAll(li2);
//		
//		System.out.println("After implementing contains all "+li);
		
		li.removeAll(li2);
		
		System.out.println("After removing elements are "+li);
		
		
		
		
		

	}

}
