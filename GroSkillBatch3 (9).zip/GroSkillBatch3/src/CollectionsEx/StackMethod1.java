package CollectionsEx;

import java.util.Stack;

public class StackMethod1 {

	public static void main(String[] args) {
	
		Stack<Integer> s1=new Stack<Integer>();
		s1.push(32);
		s1.push(45);
		s1.push(78);
		s1.push(102);
		
		for(int x:s1)
		{
			System.out.println(x);
		}
		
		s1.pop();
		s1.push(67);
		s1.pop();
		
		System.out.println(s1);
		
		

	}

}
