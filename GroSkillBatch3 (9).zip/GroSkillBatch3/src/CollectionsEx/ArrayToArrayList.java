package CollectionsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayToArrayList {

	public static void main(String[] args) {
		
//		String []a= {"Python","Java","C","C#"};
//		
//		List<String>li=Arrays.asList(a);
		
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(78);
		li.add(102);
		li.add(99);
		
		Object[] arr=li.toArray();
		
		for(Object obj:arr)
		{
			System.out.println(obj);
		}
		
		

	}

}
