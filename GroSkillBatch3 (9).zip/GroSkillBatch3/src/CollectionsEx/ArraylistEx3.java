package CollectionsEx;

import java.util.ArrayList;
import java.util.Collections;

public class ArraylistEx3 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(-2);
		li.add(-5);
		li.add(5);
		li.add(-9);
		li.add(3);
		
		ArrayList<Integer> li1=new ArrayList<Integer>();
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		
		for(int x:li)
		{
			if(x>0)
			{
				li1.add(x);
				Collections.sort(li1);
			}
			
			else
			{
				li2.add(x);
				Collections.sort(li2);
			}
		}
		
		li1.addAll(li2);
		
		System.out.println(li1);
		

	}

}
