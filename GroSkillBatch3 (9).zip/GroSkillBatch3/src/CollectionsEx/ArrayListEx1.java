package CollectionsEx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx1 {

	public static void main(String[] args) {
		
		
		List<Integer> li=new ArrayList<Integer>();
		
		li.add(45);
		li.add(99);
		li.add(102);
		li.add(321);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
//		for(int i=0;i<li.size();i++)
//		{
//			System.out.println(li[i]);
//		}
		
		
		System.out.println("Using iterator interface");
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		
		
		

	}

}
