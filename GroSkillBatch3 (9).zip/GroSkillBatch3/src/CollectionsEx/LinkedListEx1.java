package CollectionsEx;

import java.util.LinkedList;

public class LinkedListEx1 {

	public static void main(String[] args) {
		
		LinkedList<Character> li=new LinkedList<Character>();
		li.add('A');
		li.add('E');
		li.add('I');
		li.add('O');
		li.add('U');
		
		
		for(char x:li)
		{
			System.out.println(x);
		}
		
		
		

	}

}
