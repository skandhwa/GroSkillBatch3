package CollectionsEx;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx4 {

	public static void main(String[] args) {
		
		
List<Integer> li=new ArrayList<Integer>();
		
		li.add(45);
		li.add(99);
		li.add(102);
		li.add(321);
		
	boolean flag=	li.contains(45);
	
	System.out.println(flag);
	
//	li.add(5,102);
//	System.out.println(li);
	
	int y=li.get(3);
	System.out.println(y);
	
	li.set(2, 902);
	System.out.println("After adding element at 2nd index "+li);
	
	
	
		
		

	}

}
