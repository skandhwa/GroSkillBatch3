package ClassesObjects;

class A
{
	void display()
	{
		System.out.println("Hello");
	}
}


public class MyFirstObjectCreation {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();
		
		
		
		
		
		
		

	}

}
