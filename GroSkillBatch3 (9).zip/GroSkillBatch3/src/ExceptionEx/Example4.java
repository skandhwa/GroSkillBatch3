package ExceptionEx;

public class Example4 {

	public static void main(String[] args) {
		
		
		try
		{
			
			int []a=new int[5];
			a[0]=12;
			a[1]=23;
			a[2]=56;
			a[3]=78;
			a[4]=99;
			a[5]=103;
			
			for(int p:a)
			{
				System.out.println(p);
			}	
			
			
			
		int x=10;
		int y=x/0;
		System.out.println(y);
		
		
		
		
		
		String str=null;
		int q=str.length();
		System.out.println("Length of String is  "+q);
		
		
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		
		catch(NullPointerException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int m=10;
		int n=20;
		int w=m+n;
		System.out.println("Value is  "+w);
		
		
		
		

	}

}
