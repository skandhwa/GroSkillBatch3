package ExceptionEx;

public class Example2 {

	public static void main(String[] args) {
		
		int []a=new int[5];
		
		try
		{
		a[0]=12;
		a[1]=23;
		a[2]=56;
		a[3]=78;
		a[4]=99;
		a[5]=103;
		
		for(int x:a)
		{
			System.out.println(x);
		}
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with  "+e);
		}
		
		int m=10;
		int n=20;
		int w=m+n;
		System.out.println("Value is  "+w);
		
		
		
		

	}

}
