package ExceptionEx;

public class FinallyEx1 {

	public static void main(String[] args) {
		
		try
		{
		int x=10;
		int y=x/2;
		System.out.println(y);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		finally
		{
			int m=10;
			int n=20;
			int w=m+n;
			System.out.println("Value is  "+w);
		}
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
