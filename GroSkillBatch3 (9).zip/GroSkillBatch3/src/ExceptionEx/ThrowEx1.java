package ExceptionEx;


class Test1
{
	public static void validateAge(int a)
	{
		if(a>18)
		{
			System.out.println("You are elligible to vote");
		}
		else
		{
			throw new ArithmeticException("You are not elligible to vote  ");
		}
	}
}



public class ThrowEx1 {

	public static void main(String[] args) {
		
		Test1.validateAge(22);
		
		
		
		

	}

}
