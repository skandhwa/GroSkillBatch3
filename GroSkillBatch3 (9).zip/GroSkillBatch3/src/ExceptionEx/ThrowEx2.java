package ExceptionEx;

import java.io.FileNotFoundException;
import java.io.FileReader;

class Test2
{
	public static void validateFileAccess(int empid) throws FileNotFoundException
	{
		if(empid==12345)
		{
		FileReader f=new FileReader("E:\\EclipseWorkspace\\Batch3Scratch\\src\\test\\java\\extent.properties");
		System.out.println("You are allowed to access the file");
		}
		else
		{
			throw new FileNotFoundException("You are not elligible");
		}
		
	}
}




public class ThrowEx2 {

	public static void main(String[] args) throws FileNotFoundException {
		
		Test2.validateFileAccess(45678);
		
		
		
		

	}

}
