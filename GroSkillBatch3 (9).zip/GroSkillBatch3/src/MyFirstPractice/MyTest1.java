package MyFirstPractice;

public class MyTest1 {

	public static void main(String[] args) {
		
		
		System.out.println("Hello");
		int x=9/0;
		System.out.println(x);
		
		
		
		 
		
		
		

	}

}
