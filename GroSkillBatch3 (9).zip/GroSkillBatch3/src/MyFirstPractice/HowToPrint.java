package MyFirstPractice;

public class HowToPrint {

	public static void main(String[] args) {
		
		int x_=20,y=30,z=40;
		System.out.print("Value is "+x_ +"    " );
		System.out.println("Value is "+y);
		
		

	}

}
