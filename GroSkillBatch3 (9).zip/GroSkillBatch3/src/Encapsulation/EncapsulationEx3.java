package Encapsulation;

class E8
{
	private String str;
	private int x;
	
	
	
	public void setStr(String str) {
		this.str = str;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	
	
	
}




public class EncapsulationEx3 {

	public static void main(String[] args) {
		
		
		E8 obj=new E8();
		obj.setX(23);
		

	}

}
