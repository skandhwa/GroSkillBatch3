package AbstractionEx;

interface I8
{
	int display(int x,int y);
	float message();
	
}

interface I9
{
	int test();
}

class C11 implements I8,I9
{
	public int display(int x,int y)
	{
		return x*y;
	}
	public int test()
	{
		return 20-10;
	}
	
	public float message()
	{
		return 10*5;
	}
	
}





public class InterfaceEx3 {

	public static void main(String[] args) {
		
		
		

	}

}
