package ConstructorEx;


class C
{
	C()
	{
		System.out.println("Hi");
	}
	
	void test()
	{
		System.out.println("Hello");
	}
}


public class MyEx1 {

	public static void main(String[] args) {
		
		
		C obj=new C();
		obj.test();
		

	}

}
