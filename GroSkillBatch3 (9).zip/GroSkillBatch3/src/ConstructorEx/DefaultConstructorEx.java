package ConstructorEx;

class C1
{
	

	
	int x;
	void test()
	{
		System.out.println("value is "+x);
	}
}




public class DefaultConstructorEx {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.test();
		
		

	}

}
