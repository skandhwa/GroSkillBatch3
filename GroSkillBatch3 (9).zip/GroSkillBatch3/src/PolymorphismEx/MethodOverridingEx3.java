package PolymorphismEx;


public class MethodOverridingEx3 {

	public  void main(String[] args) {
		
		System.out.println("Hello");
		

	}
	
class P7 extends MethodOverridingEx3	
{
public  static void main(String[] args) {
		
		System.out.println("Hello");
		

	}
}
	

}
