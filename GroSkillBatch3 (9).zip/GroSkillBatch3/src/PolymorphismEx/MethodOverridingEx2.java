package PolymorphismEx;

class Vehicle
{
	static void run()
	{
		System.out.println("Vehicle runs");
	}
}

class Bike extends Vehicle
{
	static void run()
	{
		System.out.println("Bike runs");
	}
}



public class MethodOverridingEx2 {

	public static void main(String[] args) {
		
		Bike.run();
		Vehicle.run();
		

	}

}
