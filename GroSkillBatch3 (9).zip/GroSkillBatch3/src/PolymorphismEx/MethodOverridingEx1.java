package PolymorphismEx;

class Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
	
	
	
	
}

class HDFC extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}

class Axis extends Bank
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}




public class MethodOverridingEx1 {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
		obj.getROI(12,13);
		
		Bank obj1=new Bank();
		obj1.getROI(15, 12);
		

	}

}
