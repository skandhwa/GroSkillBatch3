package ConditionalStatementsAndLooping;

public class ifLoopEx {

	public static void main(String[] args) {
		
		int age=10;
		if(age>18)
		{
			System.out.println("You are elligible");
		}
		
		System.out.println("Exit from Program , check your elligibility in above statement, if nothing is printed you are not elligible");
		

	}

}
