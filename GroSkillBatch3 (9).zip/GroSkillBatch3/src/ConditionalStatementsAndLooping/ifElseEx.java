package ConditionalStatementsAndLooping;

public class ifElseEx {

	public static void main(String[] args) {
		
		int a=20,b=15,c=30;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("a is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		
		else
		{
			if(b>c)
			{
				System.out.println("b is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		
		
		
		
		

	}

}
