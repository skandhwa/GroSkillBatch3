package Default2;

import Default1.Ex1;

public class Ex3 extends Ex1 {

	public static void main(String[] args) {
		
		Ex3 obj=new Ex3();
		obj.display();
		
		
		

	}

}
