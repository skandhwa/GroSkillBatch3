package StringPractice;

public class StringEx1 {

	public static void main(String[] args) {
		String str="Hello";
		//String str1="Hello";
		
	str=	str.concat("Siri");
		
		System.out.println(str);
		
		

	}

}
