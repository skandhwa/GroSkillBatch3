package StringPractice;

public class STringMethods5 {

	public static void main(String[] args) {
		
		String str="Hello@saurabh@hi";
	String[]s1=	str.split("@");
	
	System.out.println(s1[1].substring(2));

	}

}
