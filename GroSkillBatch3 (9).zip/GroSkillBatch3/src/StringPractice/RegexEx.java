package StringPractice;

public class RegexEx {

	public static void main(String[] args) {
		
		String str="@^*abd123u^%";
		
	str=	str.replaceAll("[^a-zA-Z0-9]","");
	
	System.out.println(str);
		
		

	}

}
