package StringPractice;

public class StringIndexOf {

	public static void main(String[] args) {
		
		
		String str="Independent India";
		
	int x=	str.indexOf("I",5);
	
	System.out.println(x);

	}

}
