package ProtectedModifier2;

import ProtectedModifierEx.Ex6;

public class Ex5 extends Ex6  {

	public static void main(String[] args) {
		
		Ex5 obj=new Ex5();
		obj.display();
		
		
	}

}
