package ProtectedModifier2;

import ProtectedModifierEx.P4;

public class Ex4 extends P4 {

	public static void main(String[] args) {
		
		
		P4 obj=new P4();
		obj.display();

	}

}
