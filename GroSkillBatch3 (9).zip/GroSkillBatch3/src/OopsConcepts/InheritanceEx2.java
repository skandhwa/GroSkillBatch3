package OopsConcepts;

class I3
{
	void test()
	{
		System.out.println("Hi");
	}
}

class I4 extends I3
{
	void message()
	{
		System.out.println("Hello");
	}
}

class I5 extends I4
{
	void display()
	{
		System.out.println("How r u");
	}
}




public class InheritanceEx2 {

	public static void main(String[] args) {
		
		
		I5 obj=new I5();
		obj.display();
		obj.test();
		obj.message();
		

	}

}
