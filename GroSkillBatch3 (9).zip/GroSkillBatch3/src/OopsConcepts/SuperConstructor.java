package OopsConcepts;

class Vehicle
{
	Vehicle()
	{
		System.out.println("Vehicle runs");
	}
}

class Car extends Vehicle
{
	Car()
	{
		super();
		System.out.println("Car runs");
		
	}
	
	
	
}

public class SuperConstructor {

	public static void main(String[] args) {
		
		Car obj=new Car();
		
		
		
		

	}

}
