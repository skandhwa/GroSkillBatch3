package ArrayEx;

public class MultiDimensionalArrayEx {

	public static void main(String[] args) {
		
		int [][]a= {{1,2,3},{4,5,6},{7,8,9}};
		
		System.out.println("Printing elements of first multidimnsional array");
		
		for(int i=0;i<a.length;i++)//i=0,0<3
		{
			for(int j=0;j<a.length;j++)//j=0,0<3//j=1,1<3
			{
				System.out.print(a[i][j]+" ");//a[0][1]//a[0][2]
				
			}
			System.out.println();
		}
		
int [][]b= {{8,10,13},{14,15,6},{17,28,9}};
		
		System.out.println("Printing elements of second multidimnsional array");
		
		for(int i=0;i<b.length;i++)//i=0,0<3
		{
			for(int j=0;j<b.length;j++)//j=0,0<3//j=1,1<3
			{
				System.out.print(b[i][j]+" ");//a[0][1]//a[0][2]
				
			}
			System.out.println();
		}
		
		int rows=a.length;
		int cols=b.length;
		
		int sum[][]=new int [rows][cols];
		
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				sum[i][j]=a[i][j]+b[i][j];
			}
		}
		
		System.out.println("The resultant matrix is ");
		
		
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				System.out.print(sum[i][j]+"  ");
			}
			
			System.out.println();
		}
		
		

	}

}
