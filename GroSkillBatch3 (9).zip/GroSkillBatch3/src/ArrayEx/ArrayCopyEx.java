package ArrayEx;

public class ArrayCopyEx {

	public static void main(String[] args) {
		
		int []a= {12,45,67,3,19};
		int []b=new int[a.length];
		
		for(int i=0;i<a.length;i++)
		{
			b[i]=a[i];
		}
		for(int x:b)
		{
			System.out.println(x);
		}
		
		System.out.println("Printing array in reverse order");
		
		for(int j=b.length-1;j>=0;j--)
		{
			System.out.println(b[j]);
		}
		
		
		

	}

}
